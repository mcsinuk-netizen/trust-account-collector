# Windows构建与程序包获取

原生Windows EXE通过Windows构建环境生成并运行自检，Mac只负责开发和本地回归。每个程序包以随附Windows报告、构建运行及版本号为准。

## 方案A：GitHub Actions

构建仓库：[trust-account-collector](https://github.com/mcsinuk-netizen/trust-account-collector)。仓库仅上传已审计的通用源码ZIP及启动工作流；工作流选取最新版本ZIP，检查禁止目录后解压执行。历史1.0.1的[成功构建](https://github.com/mcsinuk-netizen/trust-account-collector/actions/runs/39799640603)已完成92项原生测试和冻结EXE自检，实际程序位于delivery。详见[Windows测试报告](../reports/Windows测试报告_1.0.1.md)。

1. 更新本交付仓库时只需上传经审计的通用源码ZIP，既有工作流会解压构建。另建普通源码仓库时，上传**源码包解压后的内容**（含隐藏目录`.github`）。不要上传整个开发工作目录，不要上传`private`、公司账户表、运行输出或本地配置。
2. 在仓库Actions页选择“Windows x64 build”，Run workflow。也可推送到main/master触发。
3. 工作流使用Windows Server 2022 x64、Python 3.12、系统Edge，安装锁定依赖，运行pytest（含Edge模拟及GUI后台任务），用PyInstaller onedir打包。
4. 随后实际运行生成的EXE的`--self-test`：验证PE x64、Tk、三银行本地模拟查询及原始文件下载。全部通过才压缩程序。
5. 成功后在该次运行Artifacts下载`TrustCollector-Windows-x64`，解开GitHub外层ZIP后再解开程序ZIP，把完整`TrustCollector`目录通过获准方式带入公司。

构建环境安装依赖需要互联网；完成后的程序使用公司网银和本地文件，不使用GitHub或其他云服务。GitHub托管构建仍受账号当前Actions配额影响；本地Windows构建不依赖Actions配额。

## 方案B：本地Windows

在获准的Windows 10/11 x64、Windows虚拟机或构建机安装Python 3.12 x64和Edge（仅构建机需要Python）。解压通用源码包，双击`一键构建Windows.cmd`。也可以在PowerShell运行`./scripts/build_windows.ps1`。如果组织策略不允许执行脚本，应交由获准构建环境执行，不修改或绕过该策略。

脚本新建`.build-venv`，安装`requirements-windows.lock`，测试、打包、运行EXE自检，最终输出`dist/TrustCollector-Windows-x64.zip`及SHA256。任何一步失败停止。`-SkipTests`仅供排查构建，仍强制运行EXE自检，正式交付不应跳过完整测试。

系统Edge检测路径为Program Files、Program Files (x86)、LocalAppData下标准安装位置。程序不捆绑Chromium浏览器；Playwright自身的驱动运行时随`_internal`打包。自定义Edge安装路径当前需使用公司标准安装或UIA模式，不能假定任意路径自动发现。

企业电脑只需要解压和运行EXE。未签名程序可能受组织应用控制限制；应按内部普通软件授权流程处理，不关闭安全工具。真实网银兼容性、U盾与特定公司策略仍需在目标电脑验收，构建机模拟测试不能代替。

当前1.0.2需以随交付的测试报告和对应版本EXE为准；不要用旧1.0.1二进制判断本轮修改。

## 自检

程序包附“运行自检.cmd”，仅使用虚构数据、本地模拟站点及系统Edge，结果输出到`%TEMP%\TrustCollector-selftest.json`。不连接真实银行。自检失败不得认定程序已正常部署。

官方实现依据：[Playwright下载事件](https://playwright.dev/python/docs/downloads)、[Edge通道与企业策略](https://playwright.dev/python/docs/browsers)、[iframe定位](https://playwright.dev/python/docs/frames)、[PyInstaller平台约束](https://pyinstaller.org/en/stable/operating-mode.html)、[UIA控件能力](https://pywinauto.readthedocs.io/en/latest/getting_started.html)。
