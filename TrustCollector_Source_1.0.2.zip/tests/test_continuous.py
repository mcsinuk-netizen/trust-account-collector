"""Automatic daily runs: synthetic accounts; any normal-path prompt fails the test."""
from datetime import date
from pathlib import Path
from types import SimpleNamespace
import zipfile
import pytest
from trustflow.models import Account, Query, Status, FlowError
from trustflow.control import Control
from trustflow.page import DOMDriver
from trustflow.rules import mock_profile
from trustflow.adapters import make_adapter
from trustflow.browser import BrowserManager
from trustflow.worker import Worker
from trustflow.engine import Engine
from trustflow.storage import Store
from trustflow.files import Collector


def no_prompts(kind,data):
    if kind=='prompt':raise AssertionError('Unexpected manual prompt: '+data['kind'])


def test_three_banks_24_accounts_after_login_without_prompts(browser,server,tmp_path):
    events=[];w=object.__new__(Worker);w.root=tmp_path/'worker';w.logged={'ICBC','CITIC','NINGBO'};w.handles={}
    w.emit=lambda kind,data:events.append((kind,data))
    def observe(kind,data):no_prompts(kind,data);w.emit(kind,data)
    w.control=Control(observe);w.manager=BrowserManager(w.control);profiles={};accounts=[];contexts=[]
    try:
        for bank in ('ICBC','CITIC','NINGBO'):
            ctx=browser.new_context(accept_downloads=True);contexts.append(ctx);p=ctx.new_page();p.goto(server.url+'/'+bank.lower())
            for i in range(4,9):
                p.evaluate('''n=>{if(document.body.dataset.bank==='NINGBO'){let e=document.createElement('div');e.role='option';e.textContent=n+' 虚构新增';e.onclick=()=>{document.querySelector('#account').textContent=e.textContent;selected(n);document.querySelector('#options').hidden=true};document.querySelector('#options').append(e)}else document.querySelector('#account').add(new Option('虚构新增 '+n,n))}''',f'990000000000000{i}')
            w.manager.sessions[bank]=(ctx,p);profiles[bank]=mock_profile(bank);profiles[bank]['environment']='real'
            accounts.extend(Account(bank,f'虚构{bank}{i}',f'990000000000000{i}') for i in range(1,9))
        w.do_run(accounts,Query(date(2026,10,21),date(2026,10,22)),profiles,tmp_path/'out')
        results=[data for kind,data in events if kind=='result']
        assert len(results)==24 and not any(kind=='prompt' for kind,data in events)
        for bank in profiles:
            assert [r.status for r in results if r.bank==bank]==[Status.DOWNLOADED,Status.EMPTY]+[Status.DOWNLOADED]*6
        archives=list((tmp_path/'out').glob('*.zip'));assert len(archives)==1
        with zipfile.ZipFile(archives[0]) as z:
            assert len(z.namelist())==21 and all(name.endswith('.xlsx') for name in z.namelist())
            assert {name.split('_')[0] for name in z.namelist()}=={a.project for a in accounts if not a.number.endswith('2')}
    finally:
        for ctx in contexts:ctx.close()


@pytest.mark.parametrize('setup',['manual_rows','missing_task_ready'])
def test_icbc_direct_export_does_not_require_async_manual_steps(browser,server,tmp_path,setup):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/icbc');cfg=mock_profile('ICBC')
    if setup=='manual_rows':cfg['controls']['task_rows']={'manual':True}
    else:cfg['controls'].pop('task_ready')
    d=DOMDriver(p,cfg,Control(no_prompts));ad=make_adapter('ICBC',d,tmp_path)
    try:
        for i in (1,3,2):
            path=ad.run(Account('ICBC','虚构',f'990000000000000{i}'),Query.default())
            assert (path is None)==(i==2)
        assert len(list(tmp_path.glob('*.xlsx')))==2
    finally:ctx.close()


def test_icbc_unassociated_async_export_is_exception_not_blind_download(browser,server,tmp_path):
    ctx=browser.new_context();p=ctx.new_page();p.goto(server.url+'/icbc?scenario=async');cfg=mock_profile('ICBC');cfg['controls']['task_rows']={'manual':True}
    try:
        with pytest.raises(FlowError) as e:make_adapter('ICBC',DOMDriver(p,cfg,Control(no_prompts)),tmp_path).run(Account('ICBC','虚构','9900000000000001'),Query.default())
        assert e.value.status==Status.MANUAL and p.evaluate('window.downloadedTask') is None
    finally:ctx.close()


def test_ningbo_scope_is_setup_requirement_not_per_account_confirmation(browser,server,tmp_path):
    ctx=browser.new_context();p=ctx.new_page();p.goto(server.url+'/ningbo');cfg=mock_profile('NINGBO');cfg['export_scope_confirmed']=False
    try:
        with pytest.raises(FlowError) as e:make_adapter('NINGBO',DOMDriver(p,cfg,Control(no_prompts)),tmp_path).export(Account('NINGBO','虚构','9900000000000001'),Query.default())
        assert e.value.status==Status.MANUAL
        assert p.evaluate('window.reportType') is None
    finally:ctx.close()


def test_ningbo_scope_confirmation_cannot_be_reused_for_another_report(browser,server,tmp_path):
    ctx=browser.new_context();p=ctx.new_page();p.goto(server.url+'/ningbo');cfg=mock_profile('NINGBO')
    try:
        q=Query(date(2026,10,21),date(2026,10,22),'凭证导出')
        with pytest.raises(FlowError) as e:make_adapter('NINGBO',DOMDriver(p,cfg,Control(no_prompts)),tmp_path).export(Account('NINGBO','虚构','9900000000000001'),q)
        assert e.value.status==Status.MANUAL and p.evaluate('window.reportType') is None
    finally:ctx.close()


@pytest.mark.parametrize('answer,expected,calls',[(0,Status.EMPTY,2),(1,Status.TIMEOUT,1),(2,Status.CANCELLED,1)])
def test_gui_error_handover_retry_continue_stop(tmp_path,answer,expected,calls):
    prompts=[];attempts=[]
    def emit(kind,data):
        if kind=='prompt':prompts.append(data);control.respond(answer)
    control=Control(emit)
    class Adapter:
        has_data=False
        def run(self,a,q):
            attempts.append(a.project)
            if len(attempts)==1:raise FlowError(Status.TIMEOUT,'虚构查询超时')
            return None
    store=Store(tmp_path/'state')
    try:
        engine=Engine(store,Collector(tmp_path/'out',date.today()),control,lambda a:Adapter())
        result=engine.run([Account('ICBC','虚构','9900000000000001')],Query.default(),interactive_errors=True)
        assert result[0].status==expected and len(attempts)==calls and len(prompts)==1
        assert engine.last_log.is_file()
    finally:store.close()


@pytest.mark.parametrize('answer',[2,None])
def test_error_stop_preserves_completed_zip_and_does_not_query_next_account(tmp_path,answer):
    from openpyxl import Workbook
    calls=[]
    def emit(kind,data):
        if kind=='prompt':control.respond(answer)
    control=Control(emit)
    class Adapter:
        has_data=False
        def run(self,a,q):
            calls.append(a.project)
            if a.project=='虚构异常':raise FlowError(Status.TIMEOUT,'虚构超时')
            p=tmp_path/'raw.xlsx';w=Workbook();w.active.append(['虚构',1]);w.save(p);return p
    accounts=[Account('ICBC',name,f'990000000000000{i}') for i,name in enumerate(['虚构成功','虚构异常','虚构未执行'],1)]
    store=Store(tmp_path/'s')
    try:
        e=Engine(store,Collector(tmp_path/'out',date.today()),control,lambda a:Adapter())
        rows=e.run(accounts,Query.default(),interactive_errors=True)
        assert calls==['虚构成功','虚构异常'] and rows[0].status==Status.DOWNLOADED and rows[2].status==Status.SKIPPED
        with zipfile.ZipFile(e.last_zip) as z:assert len(z.namelist())==1 and z.namelist()[0].startswith('虚构成功_')
        assert '虚构异常' in e.last_log.read_text(encoding='utf-8-sig')
    finally:store.close()
