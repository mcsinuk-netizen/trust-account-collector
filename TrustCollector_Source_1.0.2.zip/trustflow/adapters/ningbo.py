from .base import BaseAdapter
from ..models import FlowError, Status


class NingboAdapter(BaseAdapter):
    def before_account(self):
        if self.d.spec('expanded').get('manual'):
            self.d.manual('expanded','请确认查询条件已展开并显示日期、方向、金额条件，完成后继续。')
        elif self.d.configured('expanded'):
            if not self.d.visible('expanded'):
                self.d.click('expand')
                self.d.wait(lambda:self.d.visible('expanded'),Status.QUERY,'查询条件未成功展开')
        else: self.d.manual('expand','请展开查询条件后继续。')

    def export(self,a,q):
        if not self.d.cfg.get('export_scope_confirmed') or self.d.cfg.get('export_scope_report','对账单导出')!=q.report:
            raise FlowError(Status.MANUAL,'宁波报表范围尚未完成首次核验。请对照原文件核对所选报表的账户与日期范围，在银行设置保存后再运行；更换报表类型需重新核验。')
        self.d.prepare_download(self.staging); self.d.click('export')
        if self.d.spec('export_menu').get('manual'):
            self.d.manual('export_menu','请选择设置中的报表类型，确认当前账户及日期后继续。')
            return self.d.receive_download(self.staging)
        items=[m for m in self.d.all('export_menu') if m.is_visible() and self.d.read_locator(m)==q.report]
        if len(items)!=1: raise FlowError(Status.MANUAL,'导出菜单未唯一匹配设定报表类型')
        return self.d.receive_download(self.staging,lambda:self.d.click_locator(items[0]))
