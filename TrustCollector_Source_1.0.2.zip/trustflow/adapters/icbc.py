from .base import BaseAdapter
from ..models import FlowError, Status
import time


class ICBCAdapter(BaseAdapter):
    def export(self,a,q):
        # Optional asynchronous controls must not force manual direct downloads.
        baseline_ready=all(self.d.configured(k) and not self.d.spec(k).get('manual')
            for k in ('task_panel','task_open','task_close','task_ready','task_rows','task_id'))
        before=self.snapshot() if baseline_ready else None
        self.d.prepare_download(self.staging)
        self.begin_export()
        self.d.click('export')
        if self.d.cfg.get('mode')=='uia':
            if self.d.visible('async_notice'): return self.associated_task(a,q,before)
            return self.d.receive_download(self.staging)
        try:
            mode=self.d.wait(lambda:'direct' if self.d.downloads else 'async' if self.d.visible('async_notice') else False,
                Status.DOWNLOAD,'直接导出未触发文件或明确异步提示',min(self.d.timeout,5))
        except FlowError as e:
            if e.status not in (Status.DOWNLOAD,): raise
            if not self.d.configured('task_rows'): raise
            # Fallback is safe only through snapshot difference + full task metadata.
            return self.associated_task(a,q,before)
        if mode=='async': return self.associated_task(a,q,before)
        return self.d.receive_download(self.staging)

    def associated_task(self,a,q,before):
        if before is None:
            raise FlowError(Status.MANUAL,'工行已进入异步导出，但未取得导出前任务基线。请核对本次任务；补全异步任务控件后可自动关联，禁止选择历史最新记录。')
        return self.download_task(a,q,before)
