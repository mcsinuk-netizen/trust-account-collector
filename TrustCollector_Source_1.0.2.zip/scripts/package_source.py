"""Strict allowlist packaging. Never package arbitrary workspace files."""
import hashlib
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parent.parent
folders={'trustflow','tests','resources','templates','docs','.github','scripts','reports'}
top={'launcher.py','pyproject.toml','requirements.txt','requirements-dev.txt','requirements-windows.lock','TrustCollector.spec','README.md','交付清单.md','.gitignore','一键构建Windows.cmd'}
allowed_sheets={'templates/账户配置模板.xlsx','templates/虚构演示账户.xlsx'}
out=root/'delivery';out.mkdir(exist_ok=True);target=out/'TrustCollector_Source_1.0.2.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if rel.as_posix()=='docs/progress.md' or rel.parts[:2]==('docs','superpowers'):continue
        if rel.parts[:1]==('reports',) and p.name not in {'mac-pytest-1.0.2.xml','mac-selftest-1.0.2.json','测试报告.md'}:continue
        if rel.parts[:1]==('reports',) and any(x.startswith('windows-attempt-') for x in rel.parts):continue
        if not p.is_file() or any(x in rel.parts for x in ('__pycache__','.pytest_cache')):continue
        if len(rel.parts)==1:
            if rel.name not in top:continue
        elif rel.parts[0] not in folders:continue
        if p.suffix=='.xlsx' and rel.as_posix() not in allowed_sheets:continue
        if p.suffix not in {'.py','.md','.html','.js','.css','.yml','.xlsx','.txt','.toml','.spec','.cmd','.ps1','.lock','.json','.xml'} and rel.name!='.gitignore':continue
        z.write(p,rel)
print(target)
print('SHA256',hashlib.sha256(target.read_bytes()).hexdigest())
