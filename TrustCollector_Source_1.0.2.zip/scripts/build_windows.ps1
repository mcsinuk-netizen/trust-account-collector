﻿param([switch]$SkipTests)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
Set-Location (Split-Path $PSScriptRoot -Parent)
if ($env:OS -ne 'Windows_NT') { throw '必须在Windows 10/11 x64或Windows构建机执行' }
if (-not (Test-Path '.build-venv\Scripts\python.exe')) {
    py -3.12 -m venv .build-venv
    if ($LASTEXITCODE -ne 0) { throw '构建机需要Python 3.12 x64（仅构建机需要）' }
}
$Python = Join-Path (Get-Location) '.build-venv\Scripts\python.exe'
& $Python -c "import struct; assert struct.calcsize('P')==8"
if ($LASTEXITCODE -ne 0) { throw '需要64位Python' }
& $Python -m pip install -r requirements-windows.lock
if ($LASTEXITCODE -ne 0) { throw '安装构建依赖失败' }
$env:TRUST_TEST_EDGE = '1'
$env:PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = '1'
if (-not $SkipTests) {
    & $Python -m pytest -q --junitxml=reports/windows-pytest.xml
    if ($LASTEXITCODE -ne 0) { throw '测试未通过，停止构建' }
}
& $Python -m PyInstaller --clean --noconfirm TrustCollector.spec
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller构建失败' }
& $Python scripts/verify_bundle.py
if ($LASTEXITCODE -ne 0) { throw 'Windows程序包自检失败，不得交付' }
Copy-Item README.md dist/TrustCollector/使用说明.md
Copy-Item docs/首次使用_1.0.2.md dist/TrustCollector/首次使用.md
Copy-Item docs dist/TrustCollector/docs -Recurse
Copy-Item templates dist/TrustCollector/templates -Recurse
Copy-Item reports/windows-frozen-selftest.json dist/TrustCollector/Windows自检报告.json
Copy-Item reports/windows-pytest.xml dist/TrustCollector/Windows测试报告.xml
Copy-Item scripts/运行自检.cmd dist/TrustCollector/运行自检.cmd
Compress-Archive -Path dist/TrustCollector -DestinationPath dist/TrustCollector-Windows-x64.zip -Force
Get-FileHash dist/TrustCollector-Windows-x64.zip -Algorithm SHA256 | Format-List
Write-Host '构建并自检完成：dist/TrustCollector-Windows-x64.zip'
