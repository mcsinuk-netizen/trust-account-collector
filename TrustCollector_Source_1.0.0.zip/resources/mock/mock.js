const $=s=>document.querySelector(s), bank=document.body.dataset.bank;
const scenario=new URLSearchParams(location.search).get('scenario')||'normal';
window.expandClicks=0;window.downloadedTask=null;window.reportType=null;let seq=0;
const accounts=[['9900000000000001','虚构甲'],['9900000000000002','虚构乙（无流水）'],['9900000000000003','虚构丙']];
function selected(n){$('#account_verify').textContent=scenario==='wrong_account'?'9900000000000003':n;}
if(bank==='NINGBO'){
 accounts.forEach(([n,t])=>{let o=document.createElement('div');o.role='option';o.textContent=n+' '+t;o.onclick=()=>{$('#account').textContent=o.textContent;selected(n);$('#options').hidden=true};$('#options').append(o)});
 $('#account').onclick=()=>{$('#options').hidden=!$('#options').hidden};$('#account_search').oninput=e=>document.querySelectorAll('[role=option]').forEach(o=>o.hidden=!o.textContent.includes(e.target.value));
 $('#expand').onclick=()=>{window.expandClicks++;$('#expanded').hidden=!$('#expanded').hidden;$('#expand').textContent=$('#expanded').hidden?'展开':'收起'};
}else{
 accounts.forEach(([n,t])=>$('#account').add(new Option(t+' '+n,n)));
 if(scenario==='ambiguous')$('#account').add(new Option('重复 '+accounts[0][0],accounts[0][0]+'x'));
 $('#account').onchange=()=>selected($('#account').value);selected($('#account').value);
}
function download(id){window.downloadedTask=id;let link=document.createElement('a');link.href='/download?empty='+(scenario==='empty_file'?'1':'0');link.click();}
function panel(open){if(bank==='CITIC'){if(open&&!$('#task_panel').open)$('#task_panel').showModal();else if(!open)$('#task_panel').close()}else $('#task_panel').hidden=!open;}
function addTask(id,acct,start,end,status){let row=document.createElement('tr');let created=new Date(Date.now()-(id.startsWith('history')?86400000:0)).toISOString();row.innerHTML=`<td class="task_id">${id}</td><td class="task_account">${acct}</td><td class="task_start">${start}</td><td class="task_end">${end}</td><td class="task_status">${status}</td><td class="task_created">${created}</td><td><button class="task_download">下载</button></td>`;row.querySelector('button').onclick=()=>download(id);$('#tasks tbody').append(row);return row;}
if(bank!=='NINGBO'){
 addTask('history-1','9900000000000003','2026-10-01','2026-10-02','已完成');
 addTask('history-same','9900000000000001','2026-10-21','2026-10-22','已完成');
 $('#task_open').onclick=()=>panel(true);$('#task_close').onclick=()=>panel(false);
}
$('#query').onclick=()=>{
 if(scenario==='stale')return;
 if(scenario==='stale_empty'){$('#result tbody').innerHTML='';$('#result').setAttribute('data-loading','yes');return;}
 $('#ready').hidden=true;$('#empty').hidden=true;$('#error').hidden=true;$('#result tbody').innerHTML='';
 if(scenario==='timeout')return;
 setTimeout(()=>{if($('#account_verify').textContent.endsWith('2'))$('#empty').hidden=false;else $('#result tbody').innerHTML='<tr><td>2026-10-22</td><td>100（虚构）</td></tr>';$('#ready').hidden=false},80);
};
if(scenario==='stale'){$('#result tbody').innerHTML='<tr><td>旧结果</td><td>1</td></tr>';$('#ready').hidden=false;}
if(scenario==='stale_empty'){$('#empty').hidden=false;$('#ready').hidden=false;}
$('#export').onclick=()=>{
 if(scenario==='export_fail'){ $('#error').hidden=false;return; }
 if(bank==='NINGBO'){$('#export_menu').hidden=false;return}
 if(bank==='ICBC'&&scenario!=='async'){download('direct');return}
 $('#async_notice').hidden=false;panel(true);
 if(scenario==='missing_task')return;
 setTimeout(()=>{const id='current-'+(++seq);let row=addTask(id,$('#account_verify').textContent,$('#start').value,$('#end').value,'处理中');if(scenario!=='pending')setTimeout(()=>row.querySelector('.task_status').textContent='已完成',80)},80);
};
if(bank==='NINGBO')document.querySelectorAll('#export_menu button').forEach(b=>b.onclick=()=>{window.reportType=b.textContent;download('ningbo');$('#export_menu').hidden=true});
