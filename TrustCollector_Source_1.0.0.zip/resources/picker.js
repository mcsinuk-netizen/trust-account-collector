(()=>{
 if(window.__trustPicker)window.__trustPicker.stop();
 const css=e=>{
  if(e.id&&!/^\d|[0-9]{8,}|^(:r|el-id)/.test(e.id))return '#'+CSS.escape(e.id);
  for(const a of ['data-testid','name','aria-label']){let v=e.getAttribute(a);if(v&&!/[0-9]{6,}|密码|验证码|PIN/i.test(v)){let s=e.tagName.toLowerCase()+'['+a+'='+JSON.stringify(v)+']';if(document.querySelectorAll(s).length===1)return s}}
  let parts=[];while(e&&e.nodeType===1){let s=e.tagName.toLowerCase();if(e.id){parts.unshift('#'+CSS.escape(e.id));break}let siblings=[...e.parentElement?.children||[]].filter(x=>x.tagName===e.tagName);if(siblings.length>1)s+=':nth-of-type('+(siblings.indexOf(e)+1)+')';parts.unshift(s);e=e.parentElement}return parts.join(' > ')
 };
 let last=null,old='';
 const restore=()=>{if(last){last.style.outline=old;last=null}};
 const hover=e=>{restore();if(e.target.matches('input[type=password]'))return;last=e.target;old=last.style.outline;last.style.outline='3px solid #e67e22'};
 const pick=e=>{
  if(e.target.matches('input[type=password]')||/密码|验证码|U盾|PIN/i.test(e.target.getAttribute('aria-label')||''))return;
  e.preventDefault();e.stopImmediatePropagation();restore();
  let t=e.target;if(window.__trustPickRepeat)t=t.closest('tr,[role=option],[role=row],option,li')||t;
  let selector=css(t);
  if(window.__trustPickRepeat&&t.parentElement){let role=t.getAttribute('role');selector=css(t.parentElement)+' > '+t.tagName.toLowerCase()+(role?'[role='+JSON.stringify(role)+']':'');}
  window.__trustPicked={css:selector,fragile:selector.includes(':nth-of-type')};
 };
 document.addEventListener('mouseover',hover,true);document.addEventListener('click',pick,true);
 window.__trustPicked=null;
 window.__trustPicker={stop:()=>{restore();document.removeEventListener('mouseover',hover,true);document.removeEventListener('click',pick,true);delete window.__trustPicker}};
})()
