from PyInstaller.utils.hooks import collect_all
from pathlib import Path

root=Path(SPECPATH)
datas=[];binaries=[];hiddenimports=[]
for pkg in ('playwright','openpyxl','xlrd','pywinauto','psutil'):
    d,b,h=collect_all(pkg);datas+=d;binaries+=b;hiddenimports+=h
datas += [(str(root/'resources'),'resources'),(str(root/'templates'),'templates'),(str(root/'docs'),'docs')]
a=Analysis([str(root/'launcher.py')],pathex=[str(root)],binaries=binaries,datas=datas,
           hiddenimports=hiddenimports+['tkinter','tkinter.ttk','comtypes','comtypes.client'],hookspath=[],excludes=['pytest'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='TrustCollector',debug=False,bootloader_ignore_signals=False,strip=False,upx=False,console=False)
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='TrustCollector')
