@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -File scripts\build_windows.ps1
if errorlevel 1 (echo 构建未完成，请查看错误。) else (echo 构建完成，请打开dist文件夹。)
pause
