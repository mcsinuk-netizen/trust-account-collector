from .base import BaseAdapter
from ..models import FlowError, Status


class NingboAdapter(BaseAdapter):
    def before_account(self):
        if self.d.spec('expanded').get('manual'):
            self.d.manual('expanded','请确认查询条件已展开并显示日期、方向、金额条件，完成后继续。')
        elif self.d.configured('expanded'):
            if not self.d.visible('expanded'):
                self.d.click('expand')
                self.d.wait(lambda:self.d.visible('expanded'),Status.QUERY,'查询条件未成功展开')
        else: self.d.manual('expand','请展开查询条件后继续。')

    def export(self,a,q):
        if not self.d.cfg.get('export_scope_confirmed'):
            self.d.manual('export_scope','请核对所选报表覆盖当前账户和查询日期；若不一致，请停止本次任务并修正设置。')
        self.d.prepare_download(self.staging); self.d.click('export')
        if self.d.spec('export_menu').get('manual'):
            self.d.manual('export_menu','请选择设置中的报表类型，确认当前账户及日期后继续。')
            return self.d.receive_download(self.staging)
        items=[m for m in self.d.all('export_menu') if m.is_visible() and self.d.read_locator(m)==q.report]
        if len(items)!=1: raise FlowError(Status.MANUAL,'导出菜单未唯一匹配设定报表类型')
        return self.d.receive_download(self.staging,lambda:self.d.click_locator(items[0]))
