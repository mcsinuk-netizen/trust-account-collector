from .base import BaseAdapter
import time


class CITICAdapter(BaseAdapter):
    def export(self,a,q):
        if self.d.spec('task_rows').get('manual'): return self.manual_export()
        before=self.snapshot()
        self.export_started=time.time()
        self.d.click('export')
        return self.download_task(a,q,before)
