from .base import BaseAdapter
from ..models import FlowError, Status
import time


class ICBCAdapter(BaseAdapter):
    def export(self,a,q):
        if self.d.spec('task_rows').get('manual'): return self.manual_export()
        before=self.snapshot() if self.d.configured('task_rows') else set()
        self.d.prepare_download(self.staging)
        self.export_started=time.time()
        self.d.click('export')
        if self.d.cfg.get('mode')=='uia':
            if self.d.visible('async_notice'): return self.download_task(a,q,before)
            return self.d.receive_download(self.staging)
        try:
            mode=self.d.wait(lambda:'direct' if self.d.downloads else 'async' if self.d.visible('async_notice') else False,
                Status.DOWNLOAD,'直接导出未触发文件或明确异步提示',min(self.d.timeout,5))
        except FlowError as e:
            if e.status not in (Status.DOWNLOAD,): raise
            if not self.d.configured('task_rows'): raise
            # Fallback is safe only through snapshot difference + full task metadata.
            return self.download_task(a,q,before)
        if mode=='async': return self.download_task(a,q,before)
        return self.d.receive_download(self.staging)
