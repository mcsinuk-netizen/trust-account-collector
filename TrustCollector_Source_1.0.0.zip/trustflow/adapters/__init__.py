from .icbc import ICBCAdapter
from .citic import CITICAdapter
from .ningbo import NingboAdapter


def make_adapter(bank,driver,staging):
    return {'ICBC':ICBCAdapter,'CITIC':CITICAdapter,'NINGBO':NingboAdapter}[bank](driver,staging)
