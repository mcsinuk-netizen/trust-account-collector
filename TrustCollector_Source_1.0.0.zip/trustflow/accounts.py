from pathlib import Path
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from .models import Account, FlowError, Status, BANKS

HEADERS = ['银行', '信托项目名称', '银行账号', '网银下拉选项显示文字', '币种', '是否启用']


def bank_code(value):
    value = str(value or '').strip()
    for k, name in BANKS.items():
        if value == k or name[:2] in value or (k == 'ICBC' and '工行' in value):
            return k
    raise FlowError(Status.ACCOUNT, '存在未识别的开户银行，请在模板中选择三家银行之一')


def load_accounts(path):
    w = load_workbook(path, data_only=False, read_only=True)
    accounts = []
    try:
        for sheet in w:
            columns = None
            for row in sheet:
                vals = [str(c.value or '').strip() for c in row]
                if columns is None:
                    if ('银行' in vals or '开户行' in vals) and ('信托项目名称' in vals or '项目名称' in vals):
                        columns = {v:i for i,v in enumerate(vals) if v}
                    continue
                def cell(*names):
                    return next((row[columns[n]] for n in names if n in columns), None)
                def text(*names, default=''):
                    c = cell(*names)
                    if c is None or c.value is None:
                        return default
                    if c.data_type == 'f':
                        raise FlowError(Status.ACCOUNT, '账户字段含公式，请粘贴为文本值后导入')
                    return str(c.value).strip()
                project = text('信托项目名称', '项目名称')
                bank = text('银行', '开户行')
                if not project or not bank:
                    continue
                n = cell('银行账号')
                if n is not None and n.value is not None and n.data_type != 's':
                    raise FlowError(Status.ACCOUNT, '银行账号必须为文本格式，数字型长账号可能已丢失精度')
                accounts.append(Account(bank_code(bank),project,text('银行账号'),text('网银下拉选项显示文字'),text('币种',default='人民币'),text('是否启用',default='是').lower() not in ('否','0','false','停用')))
        seen = set()
        for a in accounts:
            key = (a.bank, a.identity or a.project)
            if key in seen:
                raise FlowError(Status.ACCOUNT, '存在重复账户/项目，请合并或修正后导入')
            seen.add(key)
        if not accounts:
            raise FlowError(Status.ACCOUNT, '没有识别到项目名称和开户银行表头及有效项目')
        return accounts
    finally:
        w.close()


def save_accounts(path, accounts):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    w = Workbook(); s = w.active; s.title = '账户配置'; s.append(HEADERS)
    for a in accounts:
        s.append([BANKS[a.bank],a.project,a.number,a.option,a.currency,'是' if a.enabled else '否'])
    for row in s:
        for c in row:
            c.alignment = Alignment(vertical='center', wrap_text=True)
            if c.column in (3,4):
                c.number_format = '@'
                if c.row>1 and c.value is not None: c.data_type='s'
    for c in s[1]:
        c.fill = PatternFill('solid',fgColor='24486B'); c.font = Font(color='FFFFFF',bold=True)
    for col,width in zip('ABCDEF',[18,42,28,48,14,14]): s.column_dimensions[col].width=width
    s.freeze_panes = 'C2'; s.auto_filter.ref = s.dimensions
    for col,formula in [('A','"工商银行,中信银行,宁波银行"'),('F','"是,否"')]:
        dv=DataValidation(type='list',formula1=formula); s.add_data_validation(dv); dv.add(f'{col}2:{col}500')
    w.save(path)
