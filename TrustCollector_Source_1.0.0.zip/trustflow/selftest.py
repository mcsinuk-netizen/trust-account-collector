"""Frozen/offline smoke tests, virtual data only. Exit status is the build gate."""
import json
import tempfile
from datetime import date
from pathlib import Path
from playwright.sync_api import sync_playwright
from .models import Account, Query, Status
from .control import Control
from .page import DOMDriver
from .rules import mock_profile
from .mock_server import MockServer
from .adapters import make_adapter
from .engine import Engine
from .storage import Store
from .files import Collector


def run(output=None,edge=False):
    result={'platform':'Windows' if __import__('os').name=='nt' else 'macOS/Linux','frozen':bool(getattr(__import__('sys'),'frozen',False)),'banks':{},'success':False}
    try:
        with tempfile.TemporaryDirectory() as temp,MockServer() as server,sync_playwright() as p:
            root=Path(temp);browser=p.chromium.launch(channel='msedge' if edge else None,headless=True)
            try:
                for bank in ('ICBC','CITIC','NINGBO'):
                    ctx=browser.new_context(accept_downloads=True);page=ctx.new_page();page.goto(f'{server.url}/{bank.lower()}')
                    control=Control();driver=DOMDriver(page,mock_profile(bank),control)
                    store=Store(root/bank/'state');collector=Collector(root/bank/'out',date.today())
                    try:
                        engine=Engine(store,collector,control,lambda a:make_adapter(bank,driver,collector.staging))
                        accounts=[Account(bank,'虚构自检甲','9900000000000001'),Account(bank,'虚构自检乙','9900000000000002')]
                        rows=engine.run(accounts,Query.default());ok=[r.status for r in rows]==[Status.DOWNLOADED,Status.EMPTY]
                        assert ok;assert engine.last_zip.is_file();result['banks'][bank]='pass'
                    finally:store.close();ctx.close()
            finally:browser.close()
        # Verify Tcl/Tk and bundled widgets without showing a window.
        import tkinter as tk
        r=tk.Tk();r.withdraw();r.update();r.destroy();result['tk']='pass';result['success']=True
    except Exception as e:result['error_type']=type(e).__name__
    if output:
        target=Path(output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if result['success'] else 1
