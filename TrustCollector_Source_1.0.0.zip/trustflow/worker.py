import copy
import queue
import threading
import time
from datetime import date
from pathlib import Path
from .browser import BrowserManager
from .control import Control
from .rules import mock_profile, TASK_CHILDREN, REPEATED
from .wizard import Recorder, test_rule
from .models import FlowError, Status, BANKS
from .storage import Store
from .files import Collector
from .engine import Engine
from .adapters import make_adapter
from .uia import UIADriver, edge_windows, enumerate_controls, descriptor
from .mock_server import MockServer


class Worker:
    def __init__(self,root,events):
        self.root=Path(root);self.events=events;self.jobs=queue.Queue();self.control=Control(self.emit)
        self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()
    def emit(self,kind,data): self.events.put((kind,data))
    def submit(self,kind,**data): self.jobs.put((kind,copy.deepcopy(data)))
    def loop(self):
        self.manager=BrowserManager(self.control); self.mock=None; self.handles={}; self.logged=set()
        try:
            while True:
                try: kind,data=self.jobs.get(timeout=.05)
                except queue.Empty:
                    # Sync Playwright needs calls to dispatch browser callbacks even while idle.
                    try:
                        pages=[p for ctx,_ in self.manager.sessions.values() for p in ctx.pages if not p.is_closed()]
                        if pages: pages[0].wait_for_timeout(30)
                    except Exception: pass
                    continue
                if kind=='close': break
                self.emit('busy',kind)
                try: getattr(self,'do_'+kind)(**data)
                except FlowError as e: self.emit('error',str(e))
                except Exception as e: self.emit('error','操作失败（'+type(e).__name__+'）。请检查配置或重新打开银行窗口。')
                finally: self.emit('idle',kind)
        finally:
            self.manager.close()
            if self.mock: self.mock.__exit__()
    def do_open(self,bank,profile):
        self.guard(profile)
        if profile.get('mode')=='uia':
            self.do_windows();return
        if profile.get('environment')=='mock':
            if self.mock is None: self.mock=MockServer();self.mock.__enter__()
            self.manager.open(bank,profile,f'{self.mock.url}/{bank.lower()}')
        else: self.manager.open(bank,profile)
        self.logged.discard(bank);self.emit('opened',bank)
    def do_confirm(self,bank): self.logged.add(bank);self.emit('confirmed',bank)
    def do_tabs(self,bank):
        ctx,_=self.manager.sessions[bank];self.emit('tabs',[(i,p.title()) for i,p in enumerate(ctx.pages) if not p.is_closed()])
    def do_choose_tab(self,bank,index):
        self.manager.choose_page(bank,index);self.manager.drivers.pop(bank,None)
    def do_windows(self): self.emit('windows',edge_windows())
    def do_attach(self,bank,handle): self.handles[bank]=handle; self.emit('opened',bank)
    def guard(self,profile):
        if profile.get('state')=='安全限制不可自动化':raise FlowError(Status.MANUAL,'该银行已标记安全限制不可自动化，操作已停止')
    def do_uia_controls(self,bank,profile):
        self.guard(profile)
        self.nodes=enumerate_controls(self.handles[bank]); self.emit('uia_controls',[label for _,label in self.nodes])
    def do_uia_capture(self,bank,field,index,profile):
        self.guard(profile)
        spec=descriptor(self.nodes[index][0],field in REPEATED)
        if field in TASK_CHILDREN: spec['relative']=True
        self.emit('captured',{'bank':bank,'field':field,'spec':spec})
    def do_capture(self,bank,field,profile):
        self.guard(profile)
        self.control.cancelled.clear();self.control.skip.clear()
        page=self.manager.current(bank)
        parent=profile['controls'].get('task_rows') if field in TASK_CHILDREN else None
        if field in TASK_CHILDREN and not parent: raise FlowError(Status.MANUAL,'请先捕获任务记录行，再捕获行内字段')
        r=Recorder(page,field in REPEATED,parent);r.install();page.bring_to_front()
        try:
            until=time.monotonic()+90
            while time.monotonic()<until:
                self.control.checkpoint(lambda s:page.wait_for_timeout(s*1000))
                spec=r.poll()
                if spec:
                    self.emit('captured',{'bank':bank,'field':field,'spec':spec});return
                page.wait_for_timeout(80)
            raise FlowError(Status.MANUAL,'捕获超时，请重新点击捕获')
        finally: r.uninstall()
    def do_test(self,bank,field,profile):
        self.guard(profile)
        spec=profile['controls'].get(field)
        if not spec: raise FlowError(Status.MANUAL,'该步骤尚未配置')
        if spec.get('manual'): self.emit('tested',{'field':field,'count':-1});return
        if profile.get('mode')=='uia':
            d=UIADriver(self.handles[bank],profile,self.control)
            if field in TASK_CHILDREN:
                counts=[len(d.all(field,row)) for row in d.all('task_rows')];count=min(counts) if counts else 0
            else: count=len(d.all(field))
        else: count=test_rule(self.manager.current(bank),spec,profile['controls'].get('task_rows'))
        self.emit('tested',{'field':field,'count':count})
    def do_run(self,accounts,query,profiles,output,retry_only=False,force=False):
        self.control.cancelled.clear();self.control.skip.clear();self.control.paused.clear()
        collector=Collector(output,date.today()); store=Store(self.root/'state')
        def factory(a):
            profile=profiles[a.bank]
            if profile.get('state')=='安全限制不可自动化': raise FlowError(Status.MANUAL,'该银行已标记为安全限制不可自动化，请停止并联系公司支持')
            if a.bank not in self.logged:
                if profile.get('mode')!='uia' and a.bank not in self.manager.sessions:
                    self.do_open(a.bank,profile)
                pump=None
                if profile.get('mode')!='uia':
                    page=self.manager.current(a.bank);pump=lambda s:page.wait_for_timeout(s*1000)
                self.control.ask('manual','请在'+BANKS[a.bank]+'窗口人工登录并进入资金明细页，确认后继续。',pump=pump)
                self.logged.add(a.bank)
            if profile.get('mode')=='uia':
                if a.bank not in self.handles: raise FlowError(Status.MANUAL,'请先选择现有Edge窗口')
                driver=UIADriver(self.handles[a.bank],profile,self.control)
            else:
                driver=self.manager.driver(a.bank,profile)
            return make_adapter(a.bank,driver,collector.staging)
        try:
            Engine(store,collector,self.control,factory).run(accounts,query,retry_only,force)
        finally: store.close()
