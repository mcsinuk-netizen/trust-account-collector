import os
import sys
from pathlib import Path


def resource(*parts):
    return Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent.parent)).joinpath(*parts)


def user_root():
    base=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local/share')))
    p=base/'TrustAccountCollector'; p.mkdir(parents=True,exist_ok=True); return p
