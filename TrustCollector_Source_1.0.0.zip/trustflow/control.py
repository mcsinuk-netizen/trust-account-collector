import threading
import time
from .models import FlowError, Status


class Control:
    def __init__(self,emit=lambda *args:None):
        self.emit=emit; self.paused=threading.Event(); self.cancelled=threading.Event(); self.skip=threading.Event()
        self.answer_event=threading.Event(); self.answer=None

    def checkpoint(self,pump=None):
        while self.paused.is_set():
            self._check(); (pump or time.sleep)(0.1)
        self._check()

    def _check(self):
        if self.cancelled.is_set(): raise FlowError(Status.CANCELLED,'运行已停止')
        if self.skip.is_set():
            self.skip.clear(); raise FlowError(Status.SKIPPED,'已跳过当前账户')

    def ask(self,kind,message,options=None,pump=None):
        self.answer=None; self.answer_event.clear(); self.emit('prompt',{'kind':kind,'message':message,'options':options or []})
        while not self.answer_event.is_set():
            self._check(); (pump or time.sleep)(0.1)
        if self.answer is None: raise FlowError(Status.MANUAL,'人工操作尚未确认')
        return self.answer

    def respond(self,answer): self.answer=answer; self.answer_event.set()
