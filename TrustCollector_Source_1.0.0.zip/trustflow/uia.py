"""Windows UI Automation fallback. Capability driven, no coordinate recording."""
import os
import time
from pathlib import Path
from .models import FlowError, Status
from .page import DOMDriver, matches, norm
from .files import validate_file


def _desktop():
    if os.name!='nt': raise FlowError(Status.MANUAL,'UIA备用模式仅可在Windows使用，待Windows真实网银验证')
    from pywinauto import Desktop
    return Desktop(backend='uia')


def edge_windows():
    desktop=_desktop()
    import psutil
    result=[]
    for w in desktop.windows():
        try:
            if psutil.Process(w.process_id()).name().lower()=='msedge.exe' and w.is_visible():
                result.append((w.handle,w.window_text()))
        except Exception: pass
    return result


def is_secret(w):
    try: return bool(w.element_info.element.CurrentIsPassword)
    except Exception: return True


def descriptor(w,repeat=False):
    e=w.element_info
    if is_secret(w): raise FlowError(Status.MANUAL,'不允许配置或读取密码控件')
    d={'control_type':e.control_type}
    if e.automation_id: d['auto_id']=e.automation_id
    elif e.name and not repeat: d['title']=e.name
    else:
        if not repeat: raise FlowError(Status.MANUAL,'该控件没有可靠唯一标识，请改用人工步骤')
    return d


class UIADriver(DOMDriver):
    def __init__(self,handle,profile,control):
        self.window=_desktop().window(handle=handle).wrapper_object(); self.cfg=profile; self.control=control
        self.timeout=float(profile.get('timeout',30)); self.page=None
        self.snapshot_files={}
    def pump(self,seconds=.05): time.sleep(seconds)
    def all(self,name,parent=None):
        spec=self.spec(name)
        if not spec: return []
        allowed={k:v for k,v in spec.items() if k in ('auto_id','control_type','title','class_name')}
        if not allowed: return []
        return (parent or self.window).descendants(**allowed)
    def read_locator(self,loc):
        if is_secret(loc): raise FlowError(Status.MANUAL,'密码控件不可读取')
        try:
            if loc.element_info.control_type=='Edit': return str(loc.get_value())
            if loc.element_info.control_type=='ComboBox':
                try: return norm(loc.selected_text())
                except Exception: pass
            return norm(loc.window_text())
        except Exception: raise FlowError(Status.MANUAL,'UIA控件文本不可读取，请人工接管') from None
    def click_locator(self,loc):
        self.check(); text=self.read_locator(loc)
        import re
        if re.search('转账|付款|支付|变更账户|销户|签约',text): raise FlowError(Status.MANUAL,'已阻止超出查询导出范围的操作')
        try: loc.invoke()
        except Exception:
            try: loc.select()
            except Exception: loc.click_input()
    def fill(self,name,value):
        if self.spec(name).get('manual'): self.manual(name); return
        loc=self.one(name); self.check()
        if is_secret(loc): raise FlowError(Status.MANUAL,'不允许写入密码控件')
        try:
            if loc.element_info.control_type=='ComboBox': loc.select(value)
            else: loc.set_edit_text(value)
        except Exception: self.manual(name,'此控件不支持UIA输入，请人工填写后继续。')
    def select_account(self,a):
        if not a.ready: raise FlowError(Status.ACCOUNT,'账户标识为空')
        if self.spec('account').get('manual'): self.manual('account')
        else:
            self.click('account')
            if self.configured('account_search'): self.fill('account_search',a.identity)
            hits=[x for x in self.all('options') if matches(self.read_locator(x),a)]
            if len(hits)!=1: raise FlowError(Status.ACCOUNT,'UIA无法唯一匹配账户，已停止当前账户')
            self.click_locator(hits[0])
        self.verify_account(a)
    def query(self):
        # Accessibility does not provide reliable network/DOM refresh identity.
        # A human confirms this query's completion before machine interpretation.
        self.click('query'); self.manual('query_complete','请确认本次查询已完成且页面未显示上次结果，然后继续。')
        if any(self.spec(k).get('manual') for k in ('ready','rows','empty')):
            choice=self.control.ask('choice','请按本次查询的明确完成结果选择，空白或等待状态不得视为无明细。',['本次有明细','本次明确无明细','失败或不确定'])
            if choice==0:return 'data'
            if choice==1:return 'empty'
            raise FlowError(Status.QUERY,'UIA人工确认结果失败或不明')
        if self.visible('error'): raise FlowError(Status.QUERY,'页面显示查询错误')
        if self.visible('empty') and self.visible('ready'): return 'empty'
        if self.visible('ready') and self.all('rows'): return 'data'
        raise FlowError(Status.QUERY,'UIA结果状态不明确，请人工复核')
    def prepare_download(self,folder):
        self.download_folder=Path(self.cfg.get('download_directory',str(Path.home()/'Downloads')))
        self.snapshot_files={p:(p.stat().st_size,p.stat().st_mtime_ns) for p in self.download_folder.iterdir() if p.is_file()}
    @property
    def downloads(self): return []
    def receive_download(self,folder,trigger=None):
        if trigger: trigger()
        # Bank identity is already checked by adapter, but external browser downloads cannot be attributed with certainty.
        return self.manual_file('请完成Edge保存操作，然后选择刚刚下载的本次原始文件（不要选择历史文件）。')
    def save_dialog(self,target):
        # Only an explicitly selected standard Save As dialog belonging to the Edge process is considered.
        dialogs=[w for w in _desktop().windows(class_name='#32770') if w.process_id()==self.window.process_id()]
        if len(dialogs)!=1: raise FlowError(Status.MANUAL,'未唯一识别Edge另存为对话框，请人工保存')
        dialog=dialogs[0]; edits=dialog.descendants(control_type='Edit',auto_id='1001');buttons=dialog.descendants(control_type='Button',auto_id='1')
        if len(edits)!=1 or len(buttons)!=1: raise FlowError(Status.MANUAL,'另存为控件不可可靠识别，请人工保存')
        edits[0].set_edit_text(str(target));buttons[0].invoke()
    def bind_task(self,task_id):
        hits=[r for r in self.all('task_rows') if self.read('task_id',r)==task_id]
        if len(hits)!=1:raise FlowError(Status.MANUAL,'UIA任务唯一标识不再对应一条记录')
        return hits[0]


def enumerate_controls(handle):
    w=_desktop().window(handle=handle).wrapper_object(); result=[]
    for node in w.descendants():
        try:
            if node.is_visible() and not is_secret(node):
                e=node.element_info
                if e.control_type in ('Button','Edit','ComboBox','ListItem','DataItem','Table','DataGrid','Text','Pane','MenuItem'):
                    # Names remain in live GUI only; never in diagnostics.
                    result.append((node,f'{e.control_type} | {e.automation_id or "无ID"} | {e.name[:70]}'))
        except Exception: pass
    return result
