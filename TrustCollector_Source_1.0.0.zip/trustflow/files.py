import csv
import json
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from openpyxl import load_workbook
from .models import FlowError, Status
from .storage import digest


def atomic_json(path,data):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix('.tmp'); tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(p)


def validate_file(path):
    p=Path(path)
    try:
        if not p.is_file() or p.stat().st_size==0: raise ValueError()
        ext=p.suffix.lower()
        if ext=='.xlsx':
            if not zipfile.is_zipfile(p): raise ValueError()
            with zipfile.ZipFile(p) as z:
                if sum(i.file_size for i in z.infolist())>500_000_000: raise ValueError()
                if z.testzip() or 'xl/workbook.xml' not in z.namelist(): raise ValueError()
            w=load_workbook(p,read_only=True,data_only=True); w.close()
        elif ext=='.xls':
            if p.read_bytes()[:8]!=b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1': raise ValueError()
            import xlrd
            w=xlrd.open_workbook(p,on_demand=True); w.release_resources()
        elif ext=='.csv':
            raw=p.read_bytes()
            try: text=raw.decode('utf-8-sig')
            except UnicodeDecodeError: text=raw.decode('gb18030')
            if '<html' in text[:1000].lower() or '\x00' in text: raise ValueError()
            if not any(x in text for x in (',',';','\t')): raise ValueError()
            if len(list(csv.reader(text.splitlines())))<1: raise ValueError()
        else: raise ValueError()
    except Exception as e:
        raise FlowError(Status.INVALID,'文件为空、格式不受支持或内容与扩展名不一致；原文件未归集') from e
    return p


def safe_name(value):
    value=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',value).strip(' .')[:90] or '未命名项目'
    if re.fullmatch(r'(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])',value): value='_'+value
    return value


class Collector:
    def __init__(self,root,today):
        self.root=Path(root).resolve(); self.day=today.isoformat(); self.folder=self.root/self.day
        self.folder.mkdir(parents=True,exist_ok=True); self.receipts=self.folder/'.receipts'; self.receipts.mkdir(exist_ok=True)
        self.staging=self.folder/'.staging'; self.staging.mkdir(exist_ok=True)

    def recover(self,key):
        try:
            data=json.loads((self.receipts/f'{key}.json').read_text(encoding='utf-8')); p=self.folder/data['file']
            if p.parent!=self.folder: return None
            if p.is_file() and digest(p)==data['sha']: return validate_file(p)
        except (OSError,KeyError,ValueError,FlowError): pass
        return None

    def commit(self,source,a,q,key,force=False,suffix_needed=False):
        if not force:
            existing=self.recover(key)
            if existing: return existing
        source=validate_file(source)
        base=f'{safe_name(a.project)}_{self.day}'
        if suffix_needed: base+=f'_{a.bank}_{safe_name(a.number[-4:] or key[:6])}'
        p=self.folder/f'{base}{source.suffix.lower()}'
        while p.exists(): p=self.folder/f'{base}_{uuid.uuid4().hex[:6]}{source.suffix.lower()}'
        atomic_json(self.receipts/f'{key}.json',{'file':p.name,'sha':digest(source)})
        with p.open('xb') as dst, source.open('rb') as src:
            shutil.copyfileobj(src,dst)
            dst.flush()
            import os
            os.fsync(dst.fileno())
        validate_file(p)
        return p

    def archive(self,files):
        p=self.root/f'{self.day}.zip'
        if p.exists(): p=self.root/f'{self.day}_{uuid.uuid4().hex[:6]}.zip'
        tmp=p.with_suffix('.part')
        with zipfile.ZipFile(tmp,'x',zipfile.ZIP_DEFLATED) as z:
            for f in dict.fromkeys(Path(f) for f in files):
                validate_file(f); z.write(f,f.name)
        tmp.replace(p); return p
