from dataclasses import dataclass
from datetime import date, timedelta
from enum import StrEnum

BANKS = {'ICBC': '工商银行', 'CITIC': '中信银行', 'NINGBO': '宁波银行'}


class Status(StrEnum):
    DOWNLOADED = '查询成功，有明细，下载成功'
    EMPTY = '查询成功，无明细'
    ACCOUNT = '账号匹配失败'
    QUERY = '查询失败'
    TIMEOUT = '查询超时'
    EXPORT = '导出任务未生成'
    PENDING = '导出任务未完成'
    DOWNLOAD = '下载失败'
    INVALID = '文件校验失败'
    MANUAL = '需要人工确认'
    SKIPPED = '已跳过'
    CANCELLED = '已取消'
    RUNNING = '执行中'


class FlowError(Exception):
    def __init__(self, status, message):
        self.status = status
        super().__init__(message)


@dataclass
class Account:
    bank: str
    project: str
    number: str = ''
    option: str = ''
    currency: str = '人民币'
    enabled: bool = True

    @property
    def ready(self):
        return bool(self.number or self.option)

    @property
    def masked(self):
        return '尾号' + self.number[-4:] if self.number else '唯一选项'

    @property
    def identity(self):
        return self.number or self.option


@dataclass(frozen=True)
class Query:
    start: date
    end: date
    report: str = '对账单导出'

    def __post_init__(self):
        if self.start > self.end:
            raise ValueError('开始日期不得晚于结束日期')

    @classmethod
    def default(cls):
        today = date.today()
        return cls(today - timedelta(days=1), today)
