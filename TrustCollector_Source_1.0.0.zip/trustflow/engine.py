import csv
import uuid
from collections import Counter
from dataclasses import dataclass
from .models import Status, FlowError
from .storage import RunLock


@dataclass
class Result:
    bank: str
    project: str
    account: str
    status: Status
    message: str = ''
    file: str = ''
    has_data: bool = False


class Engine:
    def __init__(self,store,collector,control,adapter_factory):
        self.store=store; self.collector=collector; self.control=control; self.factory=adapter_factory; self.last_zip=None; self.last_log=None

    def run(self,accounts,query,retry_only=False,force=False):
        results=[]; files=[]; enabled=[a for a in accounts if a.enabled]
        projects=Counter(a.project for a in enabled)
        with RunLock(self.store.root):
            for i,a in enumerate(enabled):
                key=self.store.key(a,query)
                self.control.emit('account',{'index':i+1,'total':len(enabled),'bank':a.bank,'project':a.project,'masked':a.masked})
                existing=self.store.completed(key) or self.collector.recover(key)
                result=Result(a.bank,a.project,a.masked,Status.RUNNING)
                adapter=None
                try:
                    self.control.checkpoint()
                    if not force and existing:
                        if existing.parent!=self.collector.folder:
                            existing=self.collector.commit(existing,a,query,key,suffix_needed=projects[a.project]>1)
                        files.append(existing); self.store.finish(key,Status.DOWNLOADED,existing)
                        result.status=Status.DOWNLOADED; result.message='复用已验证文件'; result.file=existing.name
                        result.has_data=True
                    elif not force and self.store.status(key)==Status.EMPTY:
                        result.status=Status.EMPTY; result.message='复用相同查询条件下的已完成结果'
                    elif retry_only and self.store.status(key) is None:
                        result.status=Status.SKIPPED; result.message='此账户未在原批次执行，不属于失败重试'
                    else:
                        self.store.finish(key,Status.RUNNING)
                        adapter=self.factory(a)
                        path=adapter.run(a,query)
                        if path is None:
                            result.status=Status.EMPTY; self.store.finish(key,result.status)
                        else:
                            self.control.emit('step','命名')
                            path=self.collector.commit(path,a,query,key,force=force,suffix_needed=projects[a.project]>1)
                            files.append(path); result.file=path.name; result.status=Status.DOWNLOADED
                            self.store.finish(key,result.status,path)
                except FlowError as e:
                    result.status=e.status; result.message=str(e)
                    self.store.finish(key,result.status)
                except Exception as e:
                    result.status=Status.QUERY
                    # Underlying Playwright/OS exceptions may contain input values and page content.
                    result.message='操作失败（'+type(e).__name__+'），请检查控件配置或重新登录'
                    self.store.finish(key,result.status)
                if adapter is not None:result.has_data=getattr(adapter,'has_data',result.status==Status.DOWNLOADED)
                results.append(result); self.control.emit('result',result)
                if result.status==Status.CANCELLED:
                    for rest in enabled[i+1:]:
                        r=Result(rest.bank,rest.project,rest.masked,Status.SKIPPED,'运行取消后未执行'); results.append(r); self.control.emit('result',r)
                    break
            self.control.emit('step','归档')
            if files: self.last_zip=self.collector.archive(files)
            self.last_log=self.collector.folder/f'查询结果_{uuid.uuid4().hex[:8]}.csv'
            with self.last_log.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.writer(f); w.writerow(['银行','信托项目','账户标识','查询开始','查询结束','状态','说明','归集文件'])
                for r in results:
                    # Prefix formula-like project names to avoid spreadsheet formula injection.
                    project="'"+r.project if r.project.startswith(('=','+','-','@')) else r.project
                    w.writerow([r.bank,project,r.account,query.start.isoformat(),query.end.isoformat(),r.status,r.message,r.file])
            self.control.emit('done',{'zip':str(self.last_zip or ''),'log':str(self.last_log)})
        return results
