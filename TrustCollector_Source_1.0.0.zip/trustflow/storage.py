import hashlib
import hmac
import json
import os
import secrets
import sqlite3
from pathlib import Path
from .models import Status


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


class Store:
    def __init__(self, root):
        self.root=Path(root); self.root.mkdir(parents=True, exist_ok=True)
        salt=self.root/'key.bin'
        try:
            with salt.open('xb') as f: f.write(secrets.token_bytes(32))
            os.chmod(salt,0o600)
        except FileExistsError: pass
        self.salt=salt.read_bytes()
        self.db=sqlite3.connect(self.root/'tasks.db')
        self.db.execute('CREATE TABLE IF NOT EXISTS tasks (key TEXT PRIMARY KEY, status TEXT, path TEXT, sha TEXT, updated TEXT DEFAULT CURRENT_TIMESTAMP)')
        self.db.commit()

    def key(self,a,q):
        data=json.dumps([a.bank,a.identity,a.currency,q.start.isoformat(),q.end.isoformat(),q.report],ensure_ascii=False)
        return hmac.new(self.salt,data.encode(),hashlib.sha256).hexdigest()

    def finish(self,key,status,path=None):
        sha=digest(path) if path else ''
        self.db.execute('INSERT OR REPLACE INTO tasks VALUES (?,?,?,?,CURRENT_TIMESTAMP)',(key,str(status),str(path or ''),sha)); self.db.commit()

    def status(self,key):
        row=self.db.execute('SELECT status FROM tasks WHERE key=?',(key,)).fetchone()
        return row[0] if row else None

    def completed(self,key):
        row=self.db.execute('SELECT status,path,sha FROM tasks WHERE key=?',(key,)).fetchone()
        if row and row[0]==Status.DOWNLOADED:
            p=Path(row[1])
            if p.is_file() and digest(p)==row[2]: return p
        return None

    def close(self): self.db.close()


class RunLock:
    def __init__(self,root): self.path=Path(root)/'run.lock'
    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True); self.file=self.path.open('a+b')
        if self.file.tell()==0: self.file.write(b'0'); self.file.flush()
        self.file.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.file.close(); raise RuntimeError('另一个任务正在运行')
        return self
    def __exit__(self,*args): self.file.close()
