from contextlib import AbstractContextManager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import urlparse, parse_qs
from io import BytesIO
from openpyxl import Workbook
from .paths import resource


class MockServer(AbstractContextManager):
    def __enter__(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self):
                url=urlparse(self.path); query=parse_qs(url.query)
                if url.path=='/download':
                    buf=BytesIO()
                    if query.get('empty')!=['1']:
                        w=Workbook(); w.active.append(['交易日期','虚构账号','收支金额']); w.active.append(['2026-10-22','9900000000000001',100]); w.save(buf)
                    data=buf.getvalue(); self.send_response(200); self.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); self.send_header('Content-Disposition','attachment; filename="mock_statement.xlsx"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
                if url.path.strip('/') in ('icbc','citic','ningbo'):
                    if query.get('scenario')==['iframe'] and 'inner' not in query:
                        data=('<html><iframe id="bank-frame" style="width:100%;height:900px" src="'+self.path+'&inner=1"></iframe></html>').encode()
                    else: data=resource('resources','mock',url.path.strip('/')+'.html').read_bytes()
                elif url.path in ('/mock.js','/mock.css'):
                    data=resource('resources','mock',url.path[1:]).read_bytes()
                else: self.send_error(404); return
                self.send_response(200); self.send_header('Content-Type','text/javascript' if url.path.endswith('.js') else 'text/css' if url.path.endswith('.css') else 'text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler); self.thread=Thread(target=self.server.serve_forever,daemon=True); self.thread.start(); self.url=f'http://127.0.0.1:{self.server.server_port}'; return self
    def __exit__(self,*args): self.server.shutdown(); self.server.server_close(); self.thread.join()
