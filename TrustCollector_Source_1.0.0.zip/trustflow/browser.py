import os
import platform
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright, Error
from .models import FlowError, Status
from .page import DOMDriver


def edge_path():
    if os.name=='nt':
        for base in ('PROGRAMFILES(X86)','PROGRAMFILES','LOCALAPPDATA'):
            p=Path(os.environ.get(base,''))/'Microsoft/Edge/Application/msedge.exe'
            if p.is_file(): return p
    elif platform.system()=='Darwin':
        p=Path('/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge')
        if p.is_file(): return p
    return None


def validate_login_url(url):
    u=urlparse(url)
    if u.scheme!='https' or not u.hostname or u.username or u.password:
        raise FlowError(Status.MANUAL,'请填写公司授权的HTTPS网银登录地址')
    if u.query or u.fragment: raise FlowError(Status.MANUAL,'登录地址不得包含会话令牌或查询参数，请填写入口网址')
    return url


class BrowserManager:
    def __init__(self,control): self.control=control; self.pw=None; self.browser=None; self.sessions={}; self.drivers={}
    def launch(self,mock=False):
        if self.browser: return
        if self.pw is None: self.pw=sync_playwright().start()
        if not mock and not edge_path(): raise FlowError(Status.MANUAL,'未检测到Microsoft Edge，请在获准环境安装Edge')
        try: self.browser=self.pw.chromium.launch(channel='msedge' if edge_path() else None,headless=False)
        except Error:
            raise FlowError(Status.MANUAL,'独立Edge自动化窗口不可用。请检查公司策略或切换UIA备用模式；禁止规避策略。') from None
    def open(self,bank,profile,url=None):
        mock=profile.get('environment')=='mock'; self.launch(mock)
        if bank not in self.sessions:
            ctx=self.browser.new_context(accept_downloads=True); page=ctx.new_page(); self.sessions[bank]=(ctx,page)
        ctx,page=self.sessions[bank]
        target=url or profile.get('login_url','')
        if not mock: target=validate_login_url(target)
        page.goto(target); page.bring_to_front(); return page
    def current(self,bank):
        if bank not in self.sessions: raise FlowError(Status.MANUAL,'请先打开该银行登录窗口并进入查询页面')
        ctx,page=self.sessions[bank]
        if page.is_closed(): raise FlowError(Status.MANUAL,'银行查询页已关闭，请重新打开')
        return page
    def choose_page(self,bank,index):
        ctx,_=self.sessions[bank]; pages=[p for p in ctx.pages if not p.is_closed()]
        self.sessions[bank]=(ctx,pages[index]); return pages[index]
    def driver(self,bank,profile):
        if bank not in self.drivers or self.drivers[bank].cfg!=profile:
            self.drivers[bank]=DOMDriver(self.current(bank),profile,self.control)
        return self.drivers[bank]
    def close(self):
        if self.browser: self.browser.close()
        if self.pw: self.pw.stop()
        self.sessions.clear();self.drivers.clear();self.browser=None;self.pw=None
