import os
import sys

# Debug protocol logging can expose input values. This application never enables it.
for key in ('DEBUG','PWDEBUG'):
    os.environ.pop(key,None)


def main():
    if '--self-test' in sys.argv:
        from trustflow.selftest import run
        output=sys.argv[sys.argv.index('--self-test')+1] if len(sys.argv)>sys.argv.index('--self-test')+1 else None
        return run(output,edge='--edge' in sys.argv)
    from trustflow.gui import main as gui
    gui();return 0


if __name__=='__main__':
    try: code=main()
    except Exception:
        # No traceback with browser or account values is written to disk.
        import tkinter as tk
        from tkinter import messagebox
        r=tk.Tk();r.withdraw();messagebox.showerror('启动失败','程序启动未完成。请检查程序包是否完整，或运行随包诊断脚本。');r.destroy();code=1
    raise SystemExit(code)
