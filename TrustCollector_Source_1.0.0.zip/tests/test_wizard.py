from trustflow.wizard import Recorder, test_rule
from trustflow.rules import mock_profile


def test_capture_stable_selector(browser,server):
    page=browser.new_page();page.goto(server.url+'/icbc');r=Recorder(page);r.install()
    page.locator('#start').click();spec=r.poll();assert spec['css']=='#start'
    assert test_rule(page,spec)==1
    r.uninstall();page.close()


def test_capture_iframe(browser,server):
    page=browser.new_page();page.goto(server.url+'/ningbo?scenario=iframe');r=Recorder(page);r.install()
    page.frame_locator('#bank-frame').locator('#expand').click();spec=r.poll()
    assert spec['frames']==['#bank-frame'] and test_rule(page,spec)==1
    r.uninstall();page.close()


def test_password_capture_blocked(browser):
    page=browser.new_page();page.set_content('<input id="p" type="password" value="SECRET">');r=Recorder(page);r.install()
    page.locator('#p').click();assert r.poll() is None;r.uninstall();page.close()


def test_relative_iframe_rule_uses_parent_frames(browser,server):
    page=browser.new_page();page.goto(server.url+'/citic?scenario=iframe');f=page.frame_locator('#bank-frame');f.locator('#task_open').click()
    parent={'css':'#tasks tbody tr','frames':['#bank-frame']}
    spec={'css':'.task_id','relative':True}
    assert test_rule(page,spec,parent)==1
    page.close()


def test_repeated_picker_generalizes_unique_row_ids(browser):
    page=browser.new_page();page.set_content('<table id="tasks"><tbody><tr id="row-a"><td>A</td></tr><tr id="row-b"><td>B</td></tr></tbody></table>')
    r=Recorder(page,repeat=True);r.install();page.locator('#row-a td').click();spec=r.poll()
    assert test_rule(page,spec)==2
    r.uninstall();page.close()
