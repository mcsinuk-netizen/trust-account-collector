from datetime import date
from pathlib import Path
import zipfile
import pytest
from openpyxl import Workbook, load_workbook
from trustflow.models import Account, Query, Status, FlowError
from trustflow.accounts import load_accounts, save_accounts
from trustflow.files import Collector, validate_file
from trustflow.storage import Store


def sample(p):
    w = Workbook(); w.active.append(['日期', '收入']); w.active.append(['2026-10-22', 100]); w.save(p)
    return p


@pytest.fixture
def account():
    return Account('ICBC', '虚构/测试项目', '9900000000000001')


@pytest.fixture
def query():
    return Query(date(2026, 10, 21), date(2026, 10, 22))


def test_excel_roundtrip_preserves_zeroes(tmp_path):
    a = Account('CITIC', '虚构甲', '000012345678901234', '虚构甲 000012345678901234')
    p = tmp_path/'a.xlsx'; save_accounts(p,[a]); assert load_accounts(p)==[a]
    assert load_workbook(p).active['C2'].data_type == 's'


def test_original_layout_no_guessed_number(tmp_path):
    w=Workbook(); s=w.active; s.append(['序号','部门','负责人','项目名称','开户行']); s.append(['募集中']); s.append([1,'A','B','虚构项目','中信银行托管']); p=tmp_path/'in.xlsx'; w.save(p)
    a=load_accounts(p)[0]; assert a.bank=='CITIC' and a.number=='' and not a.ready


def test_numeric_account_rejected(tmp_path):
    w=Workbook(); s=w.active; s.append(['银行','信托项目名称','银行账号']); s.append(['工商银行','虚构',123456789012345678]); p=tmp_path/'bad.xlsx'; w.save(p)
    with pytest.raises(FlowError): load_accounts(p)


@pytest.mark.parametrize('name,data',[('a.xlsx',b''),('a.xlsx',b'<html>login</html>'),('a.xls',b'not excel'),('a.xlsx.crdownload',b'123')])
def test_reject_invalid_download(tmp_path,name,data):
    p=tmp_path/name; p.write_bytes(data)
    with pytest.raises(FlowError): validate_file(p)


def test_commit_zip_and_resume(tmp_path,account,query):
    c=Collector(tmp_path/'out',date(2026,10,22)); st=Store(tmp_path/'state'); k=st.key(account,query)
    p=c.commit(sample(tmp_path/'raw.xlsx'),account,query,k)
    assert p.name.startswith('虚构_测试项目_2026-10-22') and p.suffix=='.xlsx'
    # 模拟文件已提交，数据库尚未写入时中断
    assert c.recover(k)==p
    st.finish(k,Status.DOWNLOADED,p); assert st.completed(k)==p
    assert account.number not in (tmp_path/'state'/'tasks.db').read_bytes().decode('latin1')
    z=c.archive([p]); assert zipfile.ZipFile(z).namelist()==[p.name]
    assert c.commit(sample(tmp_path/'raw2.xlsx'),account,query,k)==p
    p.write_bytes(b'changed'); assert st.completed(k) is None; assert c.recover(k) is None


def test_no_overwrite_and_invalid_dates(tmp_path,account,query):
    c=Collector(tmp_path/'out',query.end)
    a=c.commit(sample(tmp_path/'r.xlsx'),account,query,'one'); b=c.commit(sample(tmp_path/'r2.xlsx'),account,query,'two')
    assert a!=b and a.exists()
    with pytest.raises(ValueError): Query(query.end,query.start)


def test_duplicate_accounts_rejected(tmp_path,account):
    p=tmp_path/'a.xlsx'; save_accounts(p,[account,account])
    with pytest.raises(FlowError): load_accounts(p)
