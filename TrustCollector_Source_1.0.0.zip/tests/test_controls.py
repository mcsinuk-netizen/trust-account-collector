import threading
import time
import pytest
from trustflow.control import Control
from trustflow.models import Account, FlowError, Status
from trustflow.uia import UIADriver


def test_pause_continue_and_cancel():
    c=Control();c.paused.set();finished=threading.Event()
    t=threading.Thread(target=lambda:(c.checkpoint(),finished.set()));t.start()
    assert not finished.wait(.15);c.paused.clear();assert finished.wait(1);t.join()
    c.cancelled.set()
    with pytest.raises(FlowError) as e:c.checkpoint()
    assert e.value.status==Status.CANCELLED


def test_skip_consumed_once():
    c=Control();c.skip.set()
    with pytest.raises(FlowError) as e:c.checkpoint()
    assert e.value.status==Status.SKIPPED;c.checkpoint()


def test_uia_manual_account_verification():
    d=object.__new__(UIADriver);d.cfg={'controls':{'account':{'manual':True},'account_verify':{'manual':True}}};d.control=Control()
    d.timeout=.01
    def forbidden_read(*args):raise AssertionError('manual verification must not read inaccessible control')
    d.read=forbidden_read
    d.manual=lambda *args:None
    d.select_account(Account('ICBC','虚构','9900000000000001'))


def test_uia_manual_result():
    d=object.__new__(UIADriver);d.cfg={'controls':{'ready':{'manual':True},'rows':{'manual':True},'empty':{'manual':True}}};d.control=Control()
    d.click=lambda *args:None;d.manual=lambda *args:None
    d.control.emit=lambda kind,data:d.control.respond(1) if kind=='prompt' else None
    assert d.query()=='empty'
