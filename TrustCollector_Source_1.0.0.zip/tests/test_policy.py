import pytest
from trustflow.worker import Worker
from trustflow.rules import blank_profile
from trustflow.models import FlowError, Status


@pytest.mark.parametrize('action',['open','capture','test'])
def test_blocked_bank_never_opens_or_automates(action):
    w=object.__new__(Worker)
    p=blank_profile('ICBC');p['state']='安全限制不可自动化'
    with pytest.raises(FlowError) as e:
        if action=='open':w.do_open('ICBC',p)
        else:getattr(w,'do_'+action)('ICBC','query',p)
    assert e.value.status==Status.MANUAL
