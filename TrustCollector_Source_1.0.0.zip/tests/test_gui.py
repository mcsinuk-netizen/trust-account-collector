import time
import tkinter as tk
from trustflow.gui import App
from trustflow.models import Status


def test_gui_worker_three_bank_run(tmp_path,monkeypatch):
    # Diagnostics here are restricted to virtual bank pages and never included in production logs.
    from trustflow.adapters.base import BaseAdapter
    original=BaseAdapter.run
    def checked(self,*args):
        try:return original(self,*args)
        except Exception:
            import traceback
            traceback.print_exc();raise
    monkeypatch.setattr(BaseAdapter,'run',checked)
    root=tk.Tk();root.withdraw();app=App(root,tmp_path/'config');app.output.set(str(tmp_path/'output'))
    app.show_prompt=lambda data:app.worker.control.respond(True)
    try:
        app.load_demo();app.run()
        deadline=time.monotonic()+90
        while (app.busy or len(app.results)<6) and time.monotonic()<deadline:
            root.update();time.sleep(.02)
        assert len(app.results)==6
        assert [r.status for r in app.results]==[Status.DOWNLOADED,Status.EMPTY]*3
        assert len(list((tmp_path/'output').glob('*.zip')))==1
    finally:
        app.close();app.worker.thread.join(timeout=10)
        assert not app.worker.thread.is_alive()
