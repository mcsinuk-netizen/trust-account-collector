from datetime import date
from pathlib import Path
import zipfile
from openpyxl import Workbook
from trustflow.engine import Engine
from trustflow.models import Account, Query, Status, FlowError
from trustflow.storage import Store
from trustflow.control import Control
from trustflow.files import Collector


def test_retry_resume_and_archive(tmp_path):
    store=Store(tmp_path/'state'); collector=Collector(tmp_path/'out',date(2026,10,22)); calls=[]
    accounts=[Account('ICBC','虚构甲','9900000000000001'),Account('CITIC','虚构乙','9900000000000002')]
    q=Query(date(2026,10,21),date(2026,10,22)); failing=[True]
    class Adapter:
        def run(self,a,q):
            calls.append(a.bank)
            if a.bank=='CITIC' and failing[0]: raise FlowError(Status.TIMEOUT,'查询超时')
            p=tmp_path/(a.bank+'.xlsx');w=Workbook();w.active.append(['虚构',1]);w.save(p);return p
    engine=Engine(store,collector,Control(),lambda a:Adapter())
    first=engine.run(accounts,q); assert [r.status for r in first]==[Status.DOWNLOADED,Status.TIMEOUT]
    failing[0]=False; second=engine.run(accounts,q,retry_only=True)
    assert calls==['ICBC','CITIC','CITIC'] and second[-1].status==Status.DOWNLOADED
    assert len(zipfile.ZipFile(engine.last_zip).namelist())==2
    engine.run(accounts,q); assert len(calls)==3


def test_cancel_before_account(tmp_path):
    c=Control();c.cancelled.set();s=Store(tmp_path/'s'); e=Engine(s,Collector(tmp_path/'out',date.today()),c,lambda a:None)
    assert e.run([Account('ICBC','虚构','99000001')],Query.default())[0].status==Status.CANCELLED


def test_errors_redacted_in_local_log(tmp_path):
    secret='9900000000000001'
    class Bad:
        def run(self,a,q): raise RuntimeError(secret+' password=example')
    e=Engine(Store(tmp_path/'s'),Collector(tmp_path/'out',date.today()),Control(),lambda a:Bad())
    e.run([Account('ICBC','虚构',secret)],Query.default())
    assert secret not in e.last_log.read_text(encoding='utf-8-sig')


def test_reused_file_is_present_in_selected_output_folder(tmp_path):
    store=Store(tmp_path/'state');a=Account('ICBC','虚构项目','9900000000000001');q=Query.default();calls=[]
    class Adapter:
        def run(self,a,q):
            calls.append(a.bank);p=tmp_path/'raw.xlsx';w=Workbook();w.active.append(['虚构',1]);w.save(p);return p
    e=Engine(store,Collector(tmp_path/'first',date.today()),Control(),lambda a:Adapter());e.run([a],q)
    c=Collector(tmp_path/'new',date.today());rows=Engine(store,c,Control(),lambda a:Adapter()).run([a],q)
    assert calls==['ICBC']
    assert (c.folder/rows[0].file).is_file()
