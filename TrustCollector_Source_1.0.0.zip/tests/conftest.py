import pytest
import os
from playwright.sync_api import sync_playwright
from trustflow.mock_server import MockServer


@pytest.fixture(scope='session')
def server():
    with MockServer() as s: yield s


@pytest.fixture(scope='session')
def browser():
    with sync_playwright() as p:
        b=p.chromium.launch(channel='msedge' if os.environ.get('TRUST_TEST_EDGE')=='1' else None,headless=True); yield b; b.close()
