from datetime import date
from pathlib import Path
import pytest
from playwright.sync_api import sync_playwright
from trustflow.mock_server import MockServer
from trustflow.rules import mock_profile
from trustflow.page import DOMDriver
from trustflow.adapters import make_adapter
from trustflow.models import Account, Query, Status, FlowError
from trustflow.control import Control


@pytest.fixture
def session(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True); p=ctx.new_page()
    yield p,server,tmp_path
    ctx.close()


def setup(session,bank,scenario='normal'):
    p,s,tmp=session; p.goto(f'{s.url}/{bank.lower()}?scenario={scenario}')
    cfg=mock_profile(bank); cfg['timeout']=0.7; cfg['download_timeout']=0.7
    d=DOMDriver(p,cfg,Control()); return make_adapter(bank,d,tmp),d


Q=Query(date(2026,10,21),date(2026,10,22))


def a(bank,tail='1'):
    return Account(bank,'虚构测试项目'+tail,'990000000000000'+tail)


@pytest.mark.parametrize('bank',['ICBC','CITIC','NINGBO'])
def test_download_and_dates(session,bank):
    ad,d=setup(session,bank); path=ad.run(a(bank),Q)
    assert path.exists() and path.stat().st_size>100
    assert d.read('start')=='2026-10-21' and d.read('end')=='2026-10-22'
    assert d.read('account_verify').find(a(bank).number)>=0
    assert d.read('direction')=='全部' if bank!='ICBC' else True


@pytest.mark.parametrize('bank',['ICBC','CITIC','NINGBO'])
def test_empty_no_download(session,bank):
    ad,d=setup(session,bank); assert ad.run(a(bank,'2'),Q) is None
    assert not list(session[2].glob('*.xlsx'))


@pytest.mark.parametrize('bank',['ICBC','CITIC','NINGBO'])
def test_query_timeout(session,bank):
    ad,d=setup(session,bank,'timeout')
    with pytest.raises(FlowError) as e: ad.run(a(bank),Q)
    assert e.value.status==Status.TIMEOUT


@pytest.mark.parametrize('bank',['ICBC','CITIC','NINGBO'])
def test_wrong_selected_account_blocked(session,bank):
    ad,d=setup(session,bank,'wrong_account')
    with pytest.raises(FlowError) as e: ad.run(a(bank),Q)
    assert e.value.status==Status.ACCOUNT


@pytest.mark.parametrize('bank',['ICBC','CITIC','NINGBO'])
def test_export_failure(session,bank):
    ad,d=setup(session,bank,'export_fail')
    with pytest.raises(FlowError): ad.run(a(bank),Q)


@pytest.mark.parametrize('bank',['ICBC','CITIC','NINGBO'])
def test_zero_byte_file(session,bank):
    ad,d=setup(session,bank,'empty_file')
    with pytest.raises(FlowError) as e: ad.run(a(bank),Q)
    assert e.value.status==Status.INVALID


def test_citic_not_historical_first_row(session):
    ad,d=setup(session,'CITIC'); ad.run(a('CITIC'),Q)
    assert d.page.evaluate('window.downloadedTask')=='current-1'


def test_icbc_async(session):
    ad,d=setup(session,'ICBC','async'); ad.run(a('ICBC'),Q)
    assert d.page.evaluate('window.downloadedTask')=='current-1'


def test_ningbo_expand_only_when_collapsed(session):
    ad,d=setup(session,'NINGBO'); ad.run(a('NINGBO'),Q)
    assert d.page.evaluate('window.expandClicks')==1
    ad.run(a('NINGBO','2'),Q)
    assert d.page.evaluate('window.expandClicks')==1


def test_stale_result_cannot_pass(session):
    ad,d=setup(session,'ICBC','stale')
    with pytest.raises(FlowError) as e: ad.run(a('ICBC'),Q)
    assert e.value.status==Status.TIMEOUT


def test_citic_pending(session):
    ad,d=setup(session,'CITIC','pending')
    with pytest.raises(FlowError) as e: ad.run(a('CITIC'),Q)
    assert e.value.status==Status.PENDING


def test_citic_missing_task(session):
    ad,d=setup(session,'CITIC','missing_task')
    with pytest.raises(FlowError) as e: ad.run(a('CITIC'),Q)
    assert e.value.status==Status.EXPORT


def test_custom_account_search_and_frame(session):
    ad,d=setup(session,'NINGBO','iframe'); assert ad.run(a('NINGBO'),Q).exists()


def test_masked_or_ambiguous_option_rejected(session):
    ad,d=setup(session,'CITIC','ambiguous')
    with pytest.raises(FlowError) as e: ad.run(a('CITIC'),Q)
    assert e.value.status==Status.ACCOUNT


def test_ningbo_report_menu_type(session):
    ad,d=setup(session,'NINGBO'); q=Query(Q.start,Q.end,'英文对账单导出'); ad.run(a('NINGBO'),q)
    assert d.page.evaluate('window.reportType')=='英文对账单导出'


def test_old_task_no_download_when_no_delta(session):
    ad,d=setup(session,'CITIC','missing_task')
    with pytest.raises(FlowError): ad.run(a('CITIC'),Q)
    assert d.page.evaluate('window.downloadedTask') is None


def test_partial_refresh_does_not_accept_old_empty_marker(session):
    ad,d=setup(session,'ICBC','stale_empty')
    with pytest.raises(FlowError) as e:ad.run(a('ICBC'),Q)
    assert e.value.status==Status.TIMEOUT


def test_manual_result_can_resume_when_no_dom_markers(session):
    ad,d=setup(session,'ICBC')
    for key in ('ready','empty','rows'):d.cfg['controls'][key]={'manual':True}
    d.control.emit=lambda kind,data:d.control.respond(1) if kind=='prompt' else None
    assert ad.run(a('ICBC'),Q) is None


def test_hidden_history_reappearing_is_not_current_task(session):
    ad,d=setup(session,'CITIC','missing_task')
    d.cfg['controls']['task_created']={'css':'.task_created','relative':True}
    d.page.evaluate('''()=>{window.historyRow=document.querySelectorAll('#tasks tbody tr')[1];historyRow.remove();document.querySelector('#export').addEventListener('click',()=>document.querySelector('#tasks tbody').append(historyRow))}''')
    with pytest.raises(FlowError):ad.run(a('CITIC'),Q)
    assert d.page.evaluate('window.downloadedTask') is None


def test_missing_creation_provenance_requires_explicit_confirmation(session):
    ad,d=setup(session,'CITIC');d.cfg['controls'].pop('task_created',None)
    prompts=[]
    def respond(kind,data):
        if kind=='prompt':prompts.append(data);d.control.respond(None)
    d.control.emit=respond
    with pytest.raises(FlowError) as e:ad.run(a('CITIC'),Q)
    assert e.value.status==Status.MANUAL and prompts
    assert d.page.evaluate('window.downloadedTask') is None


def test_pending_task_refresh_button_is_used(session):
    ad,d=setup(session,'CITIC','pending');d.timeout=1.5
    d.page.evaluate('''()=>{let b=document.createElement('button');b.id='task_refresh';b.textContent='刷新';b.onclick=()=>{for(let e of document.querySelectorAll('.task_status'))e.textContent='已完成'};document.querySelector('#task_panel').append(b)}''')
    d.cfg['controls']['task_refresh']={'css':'#task_refresh'}
    assert ad.run(a('CITIC'),Q).exists()


def test_task_download_binding_survives_row_reorder(session):
    ad,d=setup(session,'CITIC')
    d.page.evaluate('''()=>{let b=document.querySelector('#tasks tbody');let ob=new MutationObserver(()=>{let row=[...b.children].find(r=>r.querySelector('.task_id').textContent==='current-1');if(row&&!window.reorderScheduled){window.reorderScheduled=true;setTimeout(()=>b.prepend(row),110)}});ob.observe(b,{childList:true})}''')
    assert ad.run(a('CITIC'),Q).exists()
    assert d.page.evaluate('window.downloadedTask')=='current-1'


def test_manual_expanded_region_resumes(session):
    ad,d=setup(session,'NINGBO');d.cfg['controls']['expanded']={'manual':True}
    def respond(kind,data):
        if kind=='prompt':
            if d.page.locator('#expanded').is_hidden():d.page.locator('#expand').click()
            d.control.respond(True)
    d.control.emit=respond
    assert ad.run(a('NINGBO'),Q).exists()


def test_manual_task_ready_resumes(session):
    ad,d=setup(session,'CITIC');d.cfg['controls']['task_ready']={'manual':True}
    d.control.emit=lambda kind,data:d.control.respond(True) if kind=='prompt' else None
    assert ad.run(a('CITIC'),Q).exists()
