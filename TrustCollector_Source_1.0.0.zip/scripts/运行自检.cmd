@echo off
chcp 65001 >nul
cd /d "%~dp0"
start /wait "" TrustCollector.exe --self-test "%TEMP%\TrustCollector-selftest.json" --edge
type "%TEMP%\TrustCollector-selftest.json"
pause
