# Collector Implementation Plan

Goal: 交付可本地配置的三银行查询归集软件，运行全部Mac可执行测试。
Architecture: 银行适配器依赖统一页面驱动，调度器依赖持久任务库和归集器，GUI通过后台线程调度。
Tech Stack: Python 3.12 / Playwright / Tkinter / SQLite / openpyxl / pywinauto / PyInstaller。
Spec: docs/superpowers/specs/2026-10-22-collector-design.md

## Global Constraints
人工登录；离线处理；不得保存登录秘密；真实数据不进源码包；任务下载必须关联；不采用固定坐标；Windows实测后才能声明EXE成功。

## Review Focus
旧结果未刷新、历史任务混淆、重复/掩码账号、落盘到状态提交中断、公司浏览器限制。

## Tasks
- [x] 1. tests/test_core.py先定义账号导入、文件校验、任务持久及重复归集行为；运行失败；实现models/accounts/storage/files/control。
- [x] 2. tests/test_banks.py定义真实浏览器模拟场景；运行失败；实现browser/page/rules、三银行适配器和模拟服务器；修复运行到全部通过。
- [x] 3. 页面捕获向导、UIA备用驱动、GUI、人工接管及调度器；通过捕获、iframe、停止恢复及会话测试。
- [x] 4. Windows构建脚本、spec、工作流、自检；生成模板与中文文档；隔离真实名单；生成源码包（原生Windows构建尚未执行）。
- [x] 5. 全套测试、编译检查、独立代码复核、修复重要发现、交付清单及边界报告。

接口: Account(bank, project, number, option, currency, enabled); Query(start,end,report); Store.key(account,query); Collector.commit(source,account,query,key); Adapter.run(account,query); Engine.run(accounts,query)。
