from .paths import resource
from .rules import TASK_CHILDREN
from .models import FlowError, Status


def scoped_page(page,spec):
    if spec.get('window')=='popup':
        others=[p for p in page.context.pages if p!=page and not p.is_closed()]
        if len(others)!=1:raise FlowError(Status.MANUAL,'请仅保留一个本次导出任务弹出页')
        return others[0]
    return page


class Recorder:
    def __init__(self,page,repeat=False,parent_spec=None): self.page=page; self.repeat=repeat; self.parent=parent_spec
    def install(self):
        script=resource('resources','picker.js').read_text(encoding='utf-8')
        for frame in self.page.frames:
            frame.evaluate('(v)=>window.__trustPickRepeat=v',self.repeat); frame.evaluate(script)
    def poll(self):
        for frame in self.page.frames:
            spec=frame.evaluate('window.__trustPicked')
            if not spec: continue
            frames=[]; child=frame
            while child.parent_frame:
                element=child.frame_element()
                selector=element.evaluate('''e=>e.id?'#'+CSS.escape(e.id):e.name?'iframe[name='+JSON.stringify(e.name)+']':null''')
                if not selector: raise FlowError(Status.MANUAL,'iframe缺少稳定标识，请改用候选控件列表或人工步骤')
                frames.insert(0,selector); child=child.parent_frame
            if frames: spec['frames']=frames
            if self.parent:
                selector=self.parent.get('css')
                element=frame.locator(spec['css'])
                if element.count()!=1: raise FlowError(Status.MANUAL,'子控件捕获需要唯一元素')
                relative=element.evaluate('''(e,selector)=>{let row=e.closest(selector);if(!row)return null;let parts=[];while(e!==row){let tag=e.tagName.toLowerCase(),cl=[...e.classList].filter(c=>!/[0-9]{5,}/.test(c));if(cl.length){parts.unshift(tag+'.'+cl.map(c=>CSS.escape(c)).join('.'));break}let siblings=[...e.parentElement.children].filter(x=>x.tagName===e.tagName);parts.unshift(tag+':nth-of-type('+(siblings.indexOf(e)+1)+')');e=e.parentElement}return parts.join(' > ')}''',selector)
                if not relative: raise FlowError(Status.MANUAL,'请点击已配置任务行中的子控件')
                spec={'css':relative,'relative':True}
                if frames:spec['frames']=frames
            return spec
        return None
    def uninstall(self):
        for frame in self.page.frames:
            try: frame.evaluate('window.__trustPicker?.stop()')
            except Exception: pass


def test_rule(page,spec,parent=None,highlight=True):
    root=scoped_page(page,spec if spec.get('window') else parent or spec)
    for f in spec.get('frames',parent.get('frames',[]) if parent and spec.get('relative') else []): root=root.frame_locator(f)
    if spec.get('relative'):
        if not parent: raise FlowError(Status.MANUAL,'请先配置任务行')
        rows=root.locator(parent['css'])
        counts=[row.locator(spec['css']).count() for row in rows.all()]
        if highlight:
            for row in rows.all()[:40]:
                for e in row.locator(spec['css']).all(): e.highlight()
        return 1 if counts and all(c==1 for c in counts) else 0
    loc=root.locator(spec['css']); count=loc.count()
    if highlight:
        for e in loc.all()[:40]: e.highlight()
    return count


test_rule.__test__=False
