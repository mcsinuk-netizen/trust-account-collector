"""Configurable read-only business driver. Never logs page content or locator errors."""
import re
import time
import uuid
import shutil
from pathlib import Path
from playwright.sync_api import Error as PlaywrightError
from .models import FlowError, Status
from .files import validate_file
from .query_watch import QueryWatch


def norm(text): return re.sub(r'\s+',' ',str(text)).strip()


def matches(text,account):
    text=norm(text)
    if account.number:
        # Complete numeric token only: suffixes and longer similar accounts are not matches.
        return account.number in re.findall(r'(?<![0-9])[0-9]{5,}(?![0-9])',text)
    return text==norm(account.option)


class DOMDriver:
    def __init__(self,page,profile,control):
        self.page=page; self.cfg=profile; self.control=control
        self.task_popup=None
        self.timeout=float(profile.get('timeout',30)); self.downloads=[]; self.progress={}; self.download_events={}; self.cdp=None
        self.page.set_default_timeout(float(profile.get('action_timeout',5))*1000)
        self.page.context.on('page',self._watch_page)
        for p in self.page.context.pages: self._watch_page(p)

    def _watch_page(self,page): page.on('download',lambda d:self.downloads.append(d))

    def pump(self,seconds=0.05): self.page.wait_for_timeout(seconds*1000)
    def check(self): self.control.checkpoint(self.pump)
    def spec(self,name): return self.cfg['controls'].get(name,{})
    def configured(self,name): return bool(self.spec(name))

    def _page_roots(self,page,spec):
        frames=spec.get('frames',[])
        if frames:
            root=page
            for frame in frames:root=root.frame_locator(frame)
            return [root]
        if self.cfg.get('discover_frames'):return list(page.frames)
        return [page]

    def _roots(self,spec,task=False):
        page=self.page
        if spec.get('window')=='popup':
            pages=[p for p in page.context.pages if not p.is_closed() and p!=page]
            panel=self.spec('task_panel')
            if task and panel.get('window')=='popup' and any(k in panel for k in ('css','role','label')):
                if self.task_popup is not None and not self.task_popup.is_closed():page=self.task_popup
                else:
                    candidates=[]
                    for candidate in pages:
                        for root in self._page_roots(candidate,panel):
                            loc=self.locate(panel,root)
                            if loc.count()==1 and loc.is_visible():candidates.append(candidate);break
                    if not candidates:return []
                    if len(candidates)!=1:raise FlowError(Status.MANUAL,'多个弹出页包含任务窗口，请人工保留本次任务页')
                    page=candidates[0];self.task_popup=page
            else:
                if not pages:return []
                if len(pages)!=1:raise FlowError(Status.MANUAL,'请关闭无关弹出页，保留本次任务窗口')
                page=pages[0]
        return self._page_roots(page,spec)

    def locate(self,spec,root):
        if spec.get('role'): return root.get_by_role(spec['role'],name=spec.get('name'),exact=True)
        if spec.get('label'): return root.get_by_label(spec['label'],exact=True)
        return root.locator(spec.get('css','__unconfigured__'))

    def all(self,name,parent=None):
        spec=self.spec(name)
        if not spec or not any(k in spec for k in ('css','role','label')): return []
        roots=[parent] if parent is not None else self._roots(spec,task=name.startswith('task_') or name in ('export_task_id','async_notice'))
        found=[]
        try:
            for root in roots: found.extend(self.locate(spec,root).all())
        except PlaywrightError: raise FlowError(Status.MANUAL,'定位规则失效，请重新捕获控件') from None
        return found

    def one(self,name,parent=None):
        locs=self.all(name,parent)
        if len(locs)!=1: raise FlowError(Status.MANUAL,'控件“'+name+'”未唯一定位，请使用适配向导修正')
        return locs[0]

    def visible(self,name):
        return any(x.is_visible() for x in self.all(name))

    def read_locator(self,loc):
        tag=loc.evaluate('(e)=>e.tagName.toLowerCase()')
        if tag=='select': return norm(loc.locator('option:checked').inner_text())
        if tag in ('input','textarea'): return loc.input_value()
        return norm(loc.inner_text())

    def read(self,name,parent=None): return self.read_locator(self.one(name,parent))

    def manual(self,name,message=None):
        self.control.ask('manual',message or '请人工完成：'+name+'。完成后点击继续。',pump=self.pump)

    def click_locator(self,loc):
        self.check()
        text=self.read_locator(loc)
        if re.search('转账|付款|支付|修改密码|变更账户|销户|签约',text):
            raise FlowError(Status.MANUAL,'该控件超出查询与导出范围，已阻止操作')
        loc.click()

    def click(self,name):
        if self.spec(name).get('manual'): self.manual(name); return
        self.click_locator(self.one(name))

    def fill(self,name,value):
        self.check()
        spec=self.spec(name)
        if spec.get('manual'): self.manual(name); return
        loc=self.one(name)
        if loc.evaluate('(e)=>e.tagName.toLowerCase()')=='select': loc.select_option(label=value)
        else:
            loc.fill(value); loc.press('Tab')

    def wait(self,predicate,status,message,timeout=None):
        deadline=time.monotonic()+(timeout if timeout is not None else self.timeout)
        while True:
            self.check()
            value=predicate()
            if value: return value
            if time.monotonic()>=deadline: raise FlowError(status,message)
            self.pump()

    def select_account(self,a):
        self.check()
        if not a.ready: raise FlowError(Status.ACCOUNT,'账号及唯一选项均为空，请补全账户配置')
        if self.spec('account').get('manual'):
            self.manual('account','请人工选择目标账户，并确认完整账号或唯一显示文字一致。')
        else:
            loc=self.one('account'); tag=loc.evaluate('(e)=>e.tagName.toLowerCase()')
            if tag=='select':
                opts=loc.locator('option').all()
                found=[o for o in opts if matches(self.read_locator(o),a) or (a.number and o.get_attribute('value')==a.number)]
                if len(found)!=1: raise FlowError(Status.ACCOUNT,'账户未唯一匹配，请核对完整账号或唯一显示文字')
                loc.select_option(value=found[0].get_attribute('value'))
            else:
                self.click('account')
                if self.configured('account_search'): self.fill('account_search',a.identity)
                seen=set(); found=None
                for _ in range(int(self.cfg.get('account_pages',30))):
                    self.check()
                    opts=[o for o in self.all('options') if o.is_visible()]
                    hits=[o for o in opts if matches(self.read_locator(o),a)]
                    if len(hits)>1: raise FlowError(Status.ACCOUNT,'存在多个相似账户选项')
                    if hits: found=hits[0]; break
                    signature=tuple(self.read_locator(o) for o in opts)
                    if signature in seen: break
                    seen.add(signature)
                    if self.configured('account_next') and self.visible('account_next'): self.click('account_next')
                    elif self.configured('options') and opts:
                        # Scroll the option container, never select by position.
                        opts[-1].evaluate('(e)=>{let p=e.parentElement;p.scrollTop+=p.clientHeight;}')
                    else: break
                    self.pump(0.15)
                if found is None: raise FlowError(Status.ACCOUNT,'未找到目标账户选项')
                self.click_locator(found)
        self.verify_account(a)

    def verify_account(self,a):
        if self.spec('account_verify').get('manual'):
            self.manual('account_verify','请对照本地账户配置核对当前完整账号/唯一选项。完全一致后继续，否则停止。')
            return True
        self.wait(lambda:matches(self.read('account_verify'),a),Status.ACCOUNT,'账户选择后校验不一致')
        return True

    def set_dates(self,q):
        for name,value in [('start',q.start),('end',q.end)]:
            if self.spec(name).get('manual') and not self.all(name):
                self.manual(name,f'请将{name}日期设为{value.isoformat()}，并确认页面实际生效值一致后继续。')
                continue
            parts=self.cfg.get('date_parts',{}).get(name)
            if parts:
                for suffix,val in [('year',str(value.year)),('month',str(value.month)),('day',str(value.day))]: self.fill(parts[suffix],val)
            else: self.fill(name,value.strftime(self.cfg.get('date_format','%Y-%m-%d')))
            expected=value.strftime(self.cfg.get('verify_date_format',self.cfg.get('date_format','%Y-%m-%d')))
            self.wait(lambda:self.read(name)==expected,Status.QUERY,'日期实际生效值不一致，已停止查询')
        for name,value in [('start',q.start),('end',q.end)]:
            if self.spec(name).get('manual') and not self.all(name): continue
            if self.read(name)!=value.strftime(self.cfg.get('verify_date_format',self.cfg.get('date_format','%Y-%m-%d'))):
                raise FlowError(Status.QUERY,'日期控件相互影响后区间不一致，已停止查询')

    def set_filters(self,a):
        if self.configured('currency'):
            self.fill('currency',a.currency)
            if not self.spec('currency').get('manual') and self.read('currency')!=a.currency: raise FlowError(Status.QUERY,'币种回读不一致')
        elif self.cfg.get('fixed_currency')!=a.currency:
            self.manual('currency','请确认本页面币种为目标币种，完成后继续。')
        if self.configured('direction'):
            self.fill('direction',self.cfg.get('all_direction','全部'))
            if not self.spec('direction').get('manual') and self.read('direction')!=self.cfg.get('all_direction','全部'): raise FlowError(Status.QUERY,'收支方向未生效')
        elif self.cfg.get('fixed_direction')!='全部': self.manual('direction','请将收支方向设置为全部后继续。')
        for name in ('amount_min','amount_max'):
            if self.configured(name):
                self.fill(name,'')
                if not self.spec(name).get('manual') and self.read(name)!='': raise FlowError(Status.QUERY,'金额筛选未清空')
            elif not self.cfg.get('fixed_amount_unlimited'): self.manual(name,'请清除金额上下限，确认金额不限后继续。')

    def query(self):
        mode=self.cfg.get('query_completion','marker')
        manual_result=self.spec('query').get('manual') or mode=='manual' or any(self.spec(k).get('manual') for k in ('rows','empty')) or (mode=='marker' and self.spec('ready').get('manual'))
        watch=QueryWatch(self)
        try:
            if self.spec('query').get('manual'):self.manual('query','请点击查询，等待本次查询完成后继续。')
            else:
                if not manual_result:watch.install()
                self.click('query')
                if not manual_result:self.wait(watch.fresh,Status.TIMEOUT,'未取得本次查询完成及结果刷新证据，不能采用历史结果')
            return self._query_result(manual_result,mode,watch)
        finally:watch.close()

    def _query_result(self,manual_result,mode,watch):
        if manual_result:
            choice=self.control.ask('choice','请仅根据本次查询的明确完成结果选择；空白或仍在等待时不要选择无明细。',['本次查询已完成，有明细','本次查询已完成，明确无明细','查询失败或状态不明'],pump=self.pump)
            if choice==0:return 'data'
            if choice==1:return 'empty'
            raise FlowError(Status.QUERY,'人工确认查询失败或状态不明')
        def completed():
            if self.visible('error'): raise FlowError(Status.QUERY,'银行页面返回查询错误')
            if mode=='marker' and not self.visible('ready'): return False
            ready_text=self.cfg.get('ready_text','')
            if mode=='marker' and ready_text and ready_text not in self.read('ready'): return False
            if self.visible('empty'):
                if not watch.updated('empty'):return False
                expected=self.cfg.get('empty_text','')
                if expected and expected not in self.read('empty'): return False
                if any(r.is_visible() for r in self.all('rows')): raise FlowError(Status.QUERY,'无数据标记与明细行冲突')
                return 'empty'
            if any(r.is_visible() for r in self.all('rows')) and watch.updated('rows'): return 'data'
            return False
        return self.wait(completed,Status.TIMEOUT,'查询未出现明确的完成及有/无明细标记')

    def task_action(self,name):
        """Task controls must belong to the explicitly recorded task window."""
        if self.spec(name).get('manual'):self.manual(name);return
        if not self.configured('task_panel'):raise FlowError(Status.MANUAL,'请先捕获任务窗口容器，再配置窗口内刷新及关闭按钮')
        panel=self.one('task_panel');target=self.one(name)
        if not target.evaluate('(e,p)=>e===p||p.contains(e)',panel.element_handle()):
            raise FlowError(Status.MANUAL,'任务操作控件不在已配置的任务窗口中，已阻止点击')
        self.click_locator(target)

    def bind_task(self,task_id,allow_missing=False):
        """Reacquire by a stable task identity, never by a remembered row position."""
        import re
        rowspec=self.spec('task_rows');idspec=self.spec('task_id')
        found=[]
        for root in self._roots(rowspec,task=True):
            allrows=self.locate(rowspec,root)
            if not idspec.get('css'):raise FlowError(Status.MANUAL,'任务ID需要行内定位规则')
            # has= must share the same frame, and the inner selector is relative to each row.
            idloc=root.locator(idspec['css']).filter(has_text=re.compile(r'^\s*'+r'\s+'.join(re.escape(part) for part in norm(task_id).split(' '))+r'\s*$'))
            found.extend(allrows.filter(has=idloc).all())
        if not found and allow_missing:return None
        if len(found)!=1:raise FlowError(Status.MANUAL,'任务唯一标识不再对应一条记录，请人工核对')
        return found[0]

    def prepare_download(self,folder):
        self.downloads.clear(); self.progress.clear(); self.download_events.clear(); self.download_folder=Path(folder); self.download_folder.mkdir(parents=True,exist_ok=True)
        # Chromium/Edge CDP progress events provide a bounded completion wait before Playwright save_as.
        # No browser policy, login or security settings are changed. Denial falls back to manual saving.
        try:
            if self.cdp is None:
                self.cdp=self.page.context.browser.new_browser_cdp_session()
                self.cdp.on('Browser.downloadProgress',lambda e:self.progress.update({e['guid']:e['state']}))
                self.cdp.on('Browser.downloadWillBegin',lambda e:self.download_events.update({e['guid']:e}))
            target=self.page.context.new_cdp_session(self.page)
            info=target.send('Target.getTargetInfo')['targetInfo']; target.detach()
            args={'behavior':'allowAndName','downloadPath':str(self.download_folder.resolve()),'eventsEnabled':True}
            if info.get('browserContextId'): args['browserContextId']=info['browserContextId']
            self.cdp.send('Browser.setDownloadBehavior',args)
            self.progress_supported=True
        except PlaywrightError: self.progress_supported=False

    def receive_download(self,folder,trigger=None):
        if trigger: trigger()
        try:
            self.wait(lambda:self.downloads,Status.DOWNLOAD,'未检测到下载开始，请检查下载提示或安全策略',self.cfg.get('download_timeout',60))
        except FlowError as e:
            if e.status==Status.DOWNLOAD and self.cfg.get('environment')!='mock':
                return self.manual_file('未检测到下载事件。请处理Edge保存提示；保存完成后选择本次文件。若银行禁止自动化，请停止。')
            raise
        if len(self.downloads)!=1: raise FlowError(Status.MANUAL,'收到多个文件，需人工核对本次下载')
        d=self.downloads[0]
        if not self.progress_supported:
            # Never block indefinitely in save_as when completion monitoring is denied.
            return self.manual_file('无法监听下载完成，请在Edge保存文件后选择本次原始文件。')
        def completed():
            candidates=[guid for guid,e in self.download_events.items() if e['suggestedFilename']==d.suggested_filename and e['url']==d.url]
            if len(candidates)>1: raise FlowError(Status.MANUAL,'存在多个同名下载，需人工确认')
            if not candidates: return False
            guid=candidates[0]
            if self.progress.get(guid)=='canceled': raise FlowError(Status.DOWNLOAD,'下载被取消')
            return guid if self.progress.get(guid)=='completed' else False
        try:
            guid=self.wait(completed,Status.DOWNLOAD,'下载未在设定时间内完成',self.cfg.get('download_timeout',60))
        except FlowError:
            d.cancel(); raise
        ext=Path(d.suggested_filename).suffix.lower()
        p=Path(folder)/(uuid.uuid4().hex+ext)
        try:
            shutil.copyfile(self.download_folder/guid,p)
            (self.download_folder/guid).unlink()
        except OSError: raise FlowError(Status.DOWNLOAD,'下载保存失败') from None
        return validate_file(p)

    def manual_file(self,message):
        path=self.control.ask('file',message,pump=self.pump)
        return validate_file(Path(path))
