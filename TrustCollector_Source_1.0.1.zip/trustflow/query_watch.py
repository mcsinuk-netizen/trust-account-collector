"""Per-query completion evidence; no request bodies, tokens or page data are persisted."""
import time
import uuid
from urllib.parse import urlsplit
from .models import FlowError, Status
from .wizard import scoped_page


class QueryWatch:
    def __init__(self,driver):
        self.d=driver;self.page=scoped_page(driver.page,driver.spec('query'));self.token=uuid.uuid4().hex
        self.query_element=None;self.result_after=0
        self.started=set();self.finished=set();self.failed=set();self.statuses={}
        self.version=0;self.last_change=time.monotonic();self.listeners=[]

    def install(self):
        for name in ('result','rows','ready','empty'):
            spec=self.d.spec(name)
            if spec.get('css'):
                # Observe the document even when a status/row does not exist yet.
                locs=[root.locator('html') for root in self.d._roots(spec)]
            else:locs=self.d.all(name)
            for loc in locs:
                loc.evaluate('''(e,a)=>{
                    window.__trustWatches=window.__trustWatches||{};
                    let roots=()=>a.css?[...document.querySelectorAll(a.css)]:[e];
                    let state={changes:[]},previous=roots();
                    let observer=new MutationObserver(records=>{
                        let current=roots(),all=[...previous,...current];
                        if(records.some(r=>{
                            if(['result','rows'].includes(a.name)&&r.type==='attributes')return false;
                            return all.some(root=>r.target===root||root.contains(r.target)||
                                [...r.addedNodes,...(a.name==='rows'?[]:r.removedNodes)].some(n=>n===root||n.nodeType===1&&n.contains(root)));
                        }))state.changes.push(performance.timeOrigin+performance.now());
                        previous=current;
                    });
                    observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true});
                    state.observer=observer;window.__trustWatches[a.key]=state;
                }''',{'key':self.token+'_'+name,'name':name,'css':spec.get('css')})
        self.query_element=self.d.one('query')
        self.query_element.evaluate('''(e,key)=>{
            window.__trustQueryClicks=window.__trustQueryClicks||{};
            let state={at:0};state.listener=event=>{if(event.isTrusted&&!state.at)state.at=performance.timeOrigin+performance.now()};
            window.__trustQueryClicks[key]=state;e.addEventListener('click',state.listener,true);
        }''',self.token)
        if self.d.cfg.get('query_completion')=='table_response':
            rule=self.d.cfg.get('query_response',{})
            if not rule.get('path') or not rule['path'].startswith('/'):
                raise FlowError(Status.MANUAL,'请先在适配向导捕获查询响应，或选择人工判定完成')
            def matches(request):
                u=urlsplit(request.url)
                return request.resource_type in ('xhr','fetch') and u.path==rule['path'] and request.method==rule.get('method','GET') and (not rule.get('origin') or f'{u.scheme}://{u.netloc}'==rule['origin'])
            def request_started(request):
                if matches(request):self.started.add(request)
            def responded(response):
                if response.request in self.started:self.statuses[response.request]=response.status
            def ended(request):
                if request in self.started:self.finished.add(request)
            def failed(request):
                if request in self.started:self.failed.add(request)
            for name,handler in [('request',request_started),('response',responded),('requestfinished',ended),('requestfailed',failed)]:
                self.page.on(name,handler);self.listeners.append((name,handler))

    def frames(self):
        return [f for page in self.page.context.pages if not page.is_closed() for f in page.frames]

    def clicked_at(self):
        if self.query_element is None:return 0
        return self.query_element.evaluate('(e,k)=>(window.__trustQueryClicks||{})[k]?.at||0',self.token)

    def count(self,name,after):
        return sum(f.evaluate('(a)=>((window.__trustWatches||{})[a.key]?.changes||[]).filter(t=>t>=a.after).length',{'key':self.token+'_'+name,'after':after}) for f in self.frames())

    def updated(self,name):
        return self.count(name,self.result_after)>0

    def fresh(self):
        after=self.clicked_at()
        if not after:return False
        self.result_after=after
        if self.d.cfg.get('query_completion')!='table_response':
            return self.d.visible('ready') and self.count('ready',after)>0 and (self.count('result',after)>0 or self.count('empty',after)>0)
        current={r for r in self.started if r.timing['startTime']>=after}
        if any(r in current and s>=400 for r,s in self.statuses.items()) or self.failed&current:raise FlowError(Status.QUERY,'本次查询请求失败，未采用旧查询结果')
        if len(current)>1:raise FlowError(Status.MANUAL,'同一查询响应规则命中多个请求，请缩小规则或人工确认结果')
        completed=self.finished&current
        # Clearing old rows before a response is only loading, never a fresh result.
        response_at=max([after]+[r.timing['startTime']+max(0,r.timing['responseStart']) for r in completed])
        self.result_after=response_at
        version=self.count('result',response_at)
        if version!=self.version:self.version=version;self.last_change=time.monotonic()
        return bool(completed) and version>0 and time.monotonic()-self.last_change>=float(self.d.cfg.get('result_settle',.3))

    def close(self):
        for name,handler in self.listeners:self.page.remove_listener(name,handler)
        if self.query_element is not None:
            try:self.query_element.evaluate('''(e,k)=>{let s=(window.__trustQueryClicks||{})[k];if(s)e.removeEventListener('click',s.listener,true);delete (window.__trustQueryClicks||{})[k]}''',self.token)
            except Exception:pass
        for frame in self.frames():
            try:frame.evaluate('''k=>{for(let key of Object.keys(window.__trustWatches||{}))if(key.startsWith(k)){window.__trustWatches[key].observer.disconnect();delete window.__trustWatches[key]}}''',self.token)
            except Exception:pass
