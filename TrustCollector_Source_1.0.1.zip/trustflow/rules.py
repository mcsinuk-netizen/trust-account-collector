import json
from copy import deepcopy
from .paths import resource
from .files import atomic_json

FIELDS = {
 'account':'账户选择框', 'options':'账户选项（重复控件）', 'account_search':'账户搜索框（可选）',
 'account_next':'账户下一页（可选）', 'account_verify':'选中账号回读控件',
 'start':'起始日期', 'end':'结束日期', 'currency':'币种', 'direction':'收支方向',
 'amount_min':'金额下限', 'amount_max':'金额上限', 'query':'查询按钮',
 'result':'结果表格/容器', 'rows':'交易数据行（重复控件）', 'ready':'查询完成标记',
 'empty':'无数据提示', 'error':'错误提示', 'expand':'展开按钮', 'expanded':'已展开区域',
 'export':'导出/明细导出按钮', 'export_menu':'报表菜单项（重复控件）',
 'async_notice':'异步任务已提交提示', 'task_open':'任务记录入口', 'task_close':'关闭任务窗口',
 'task_rows':'任务记录行（重复控件）','task_id':'任务唯一标识', 'task_account':'任务账号',
 'task_start':'任务开始日期','task_end':'任务结束日期','task_status':'任务状态','task_download':'任务下载按钮',
 'task_ready':'任务列表已加载标记','task_refresh':'刷新导出记录（可选）',
 'task_created':'任务创建时间（推荐）','export_task_id':'本次提交返回的任务ID（可选）',
 'task_panel':'导出任务窗口容器',
}
TASK_CHILDREN={'task_id','task_account','task_start','task_end','task_status','task_download','task_created'}
REPEATED={'options','rows','export_menu','task_rows'}


def blank_profile(bank):
    return {'version':1,'bank':bank,'environment':'real','state':'尚未配置','mode':'dom','login_url':'',
            'timeout':30,'download_timeout':60,'date_format':'%Y-%m-%d','controls':{},
            'ready_text':'','empty_text':'','done_states':['完成','成功','已完成','可下载'],
            'failed_states':['失败','取消','错误'],'export_scope_confirmed':False,
            'fixed_currency':'','fixed_direction':'','fixed_amount_unlimited':False}


def load_profile(path,bank):
    try:
        p=json.loads(path.read_text(encoding='utf-8'))
        if p['bank']!=bank: raise ValueError('银行配置不一致')
        return p
    except FileNotFoundError: return blank_profile(bank)


def save_profile(path,profile): atomic_json(path,profile)


def mock_profile(bank):
    p=blank_profile(bank); p.update(environment='mock',state='已成功适配',discover_frames=True,
        export_scope_confirmed=True,fixed_currency='人民币')
    c=p['controls']
    ids=['account','account_verify','start','end','query','result','ready','empty','error','export']
    for k in ids: c[k]={'css':'#'+k}
    c['rows']={'css':'#result tbody tr'}
    if bank=='ICBC':
        c['currency']={'css':'#currency'}; p['fixed_direction']='全部'; p['fixed_amount_unlimited']=True
    else:
        for k in ('direction','amount_min','amount_max'): c[k]={'css':'#'+k}
    if bank=='NINGBO':
        c.update({k:{'css':'#'+k} for k in ('expand','expanded','account_search')})
        c['options']={'css':'#options [role=option]'}; c['export_menu']={'css':'#export_menu button'}
    else:
        c['task_panel']={'css':'#task_panel'}
        c.update({k:{'css':'#'+k} for k in ('task_open','task_close','async_notice')})
        c['task_rows']={'css':'#tasks tbody tr'}
        c['task_ready']={'css':'#task_panel'}
        for k in TASK_CHILDREN: c[k]={'css':'.'+k,'relative':True}
    return p
