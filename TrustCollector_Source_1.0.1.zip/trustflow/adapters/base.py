import time
from datetime import datetime
from pathlib import Path
from ..models import FlowError, Status
from ..page import matches


class BaseAdapter:
    def __init__(self,driver,staging): self.d=driver; self.staging=Path(staging)
    def step(self,name): self.d.control.emit('step',name); self.d.check()

    def run(self,a,q):
        self.has_data=False
        self.step('账户选择'); self.before_account(); self.d.select_account(a)
        self.step('日期设置'); self.d.set_dates(q); self.d.set_filters(a)
        self.d.verify_account(a)
        self.step('查询'); result=self.d.query()
        self.step('结果判断')
        if result=='empty': return None
        self.has_data=True
        self.d.verify_account(a)
        self.step('导出'); path=self.export(a,q)
        self.step('下载'); return path

    def before_account(self): pass
    def export(self,a,q): raise NotImplementedError

    def open_tasks(self):
        if self.d.configured('task_panel') and self.d.visible('task_panel'):return
        if self.d.configured('task_open'):
            # Open only if task rows are not visible; a new task window may already be open.
            if not any(r.is_visible() for r in self.d.all('task_rows')): self.d.click('task_open')

    def close_tasks(self):
        if self.d.spec('task_close').get('manual'):self.d.manual('task_close','请关闭本次导出任务窗口后继续。')
        elif self.d.configured('task_close') and self.d.visible('task_close'):
            self.d.task_action('task_close')
            if self.d.configured('task_panel'):
                self.d.wait(lambda:not self.d.visible('task_panel'),Status.EXPORT,'任务窗口尚未关闭，已停止重新打开')

    def begin_export(self):
        self.export_started=time.time();self.previous_export_id=''
        if self.d.configured('export_task_id') and not self.d.spec('export_task_id').get('manual'):
            self.previous_export_id=self.export_receipt()

    def export_receipt(self):
        if not self.d.all('export_task_id'):return ''
        return self.d.read('export_task_id')

    def verify_task_metadata(self,row,a,q):
        fields=('task_account','task_start','task_end')
        if all(self.d.configured(x) and not self.d.spec(x).get('manual') for x in fields):
            fmt=self.d.cfg.get('task_date_format',self.d.cfg.get('date_format','%Y-%m-%d'))
            if not matches(self.d.read('task_account',row),a) or self.d.read('task_start',row)!=q.start.strftime(fmt) or self.d.read('task_end',row)!=q.end.strftime(fmt):
                raise FlowError(Status.MANUAL,'任务刷新后账户或日期不再匹配，已停止下载')

    def task_id(self,row):
        return self.d.read('task_id',row)

    def snapshot(self):
        self.open_tasks()
        if self.d.configured('task_ready') and not self.d.spec('task_ready').get('manual'):
            self.d.wait(lambda:self.d.visible('task_ready'),Status.EXPORT,'任务列表未加载完成')
        else:
            self.d.manual('task_ready','请等待任务列表加载完成（包括历史任务），确认后继续。')
        rows=self.d.all('task_rows')
        ids=[self.task_id(r) for r in rows]
        if len(ids)!=len(set(ids)) or any(not x for x in ids): raise FlowError(Status.MANUAL,'导出任务缺少可靠唯一标识，需先修正任务行配置')
        self.close_tasks(); return set(ids)

    def download_task(self,a,q,before):
        self.open_tasks()
        if self.d.configured('task_ready') and not self.d.spec('task_ready').get('manual'):
            self.d.wait(lambda:self.d.visible('task_ready'),Status.EXPORT,'导出任务窗口未加载完成')
        else:self.d.manual('task_ready','请等待本次导出任务窗口加载完成后继续。')
        seen_new=False; pending=False
        refresh_at=time.monotonic()+1
        def refresh():
            nonlocal refresh_at
            if self.d.configured('task_refresh') and time.monotonic()>=refresh_at:
                self.d.task_action('task_refresh');refresh_at=time.monotonic()+float(self.d.cfg.get('refresh_interval',1))
        def provenance(row):
            if self.d.configured('export_task_id') and not self.d.spec('export_task_id').get('manual'):
                expected=self.export_receipt()
                if expected and expected!=self.previous_export_id:return expected==self.task_id(row)
            if self.d.configured('task_created') and not self.d.spec('task_created').get('manual'):
                raw=self.d.read('task_created',row)
                try:
                    try:created=datetime.fromisoformat(raw.replace('Z','+00:00')).timestamp()
                    except ValueError:created=datetime.strptime(raw,self.d.cfg.get('task_created_format','%Y-%m-%d %H:%M:%S')).timestamp()
                    # Rounded second supports bank timestamps with second precision. No clock-skew bypass.
                    return int(self.export_started)<=created<=time.time()+1
                except (ValueError,AttributeError):return None
            return None
        def find():
            nonlocal seen_new,pending,refresh_at
            refresh()
            rows=self.d.all('task_rows'); new=[r for r in rows if self.task_id(r) not in before]
            if new: seen_new=True
            hits=[];unproven=[]
            for row in new:
                fields=('task_account','task_start','task_end','task_status')
                if not all(self.d.configured(x) and not self.d.spec(x).get('manual') for x in fields):
                    return self.choose_manually(new,'任务信息不足，请核对银行页面并人工选择本次任务。')
                row=self.d.bind_task(self.task_id(row))
                acct=self.d.read('task_account',row)
                start=self.d.read('task_start',row); end=self.d.read('task_end',row)
                fmt=self.d.cfg.get('task_date_format',self.d.cfg.get('date_format','%Y-%m-%d'))
                if matches(acct,a) and start==q.start.strftime(fmt) and end==q.end.strftime(fmt):
                    proof=provenance(row)
                    if proof is False:continue
                    if proof is None:
                        unproven.append(row)
                    else:hits.append(row)
            if unproven:
                return self.choose_manually(hits+unproven,'账号及日期匹配，但缺少可靠的本次任务ID/创建时间。请人工核对候选确为本次创建；无法确认则停止。')
            if len(hits)>1: return self.choose_manually(hits,'有多个本次查询候选，请人工核对并选择对应任务。')
            if len(hits)==1: return hits[0]
            return False
        try:
            row=self.d.wait(find,Status.EXPORT,'未生成可关联本次账户及日期的导出任务')
            selected_id=self.task_id(row)
            def ready():
                nonlocal row
                refresh()
                row=self.d.bind_task(selected_id,allow_missing=True)
                if row is None:return False
                self.verify_task_metadata(row,a,q)
                state=self.d.read('task_status',row)
                if any(s in state for s in self.d.cfg.get('failed_states',['失败'])): raise FlowError(Status.EXPORT,'银行导出任务生成失败')
                return state in self.d.cfg.get('done_states',['已完成'])
            if not self.d.configured('task_status') or self.d.spec('task_status').get('manual'):
                self.d.manual('task_status','请核对已选本次任务的账号、日期及已完成状态，完全一致后继续。')
            else:self.d.wait(ready,Status.PENDING,'对应导出任务尚未完成')
            self.d.prepare_download(self.staging)
            if self.d.configured('task_status') and not self.d.spec('task_status').get('manual'):
                self.d.wait(ready,Status.PENDING,'下载前任务状态未完成')
            else:row=self.d.bind_task(selected_id)
            self.verify_task_metadata(row,a,q)
            path=self.d.receive_download(self.staging,lambda:self.d.click_locator(self.d.one('task_download',row)))
            return path
        finally: self.close_tasks()

    def manual_export(self):
        self.d.manual('export','请人工导出本次账户及日期的文件；有任务列表时核对任务归属并等待完成。保存文件后继续。')
        return self.d.manual_file('请选择刚刚人工核对并保存的本次银行原始明细文件。')

    def choose_manually(self,rows,message):
        for i,row in enumerate(rows):
            if self.d.cfg.get('mode')!='uia':
                row.evaluate('''(e,n)=>{e.style.outline='3px solid orange';e.setAttribute('data-trust-candidate',n);if(!document.querySelector('#trust-candidate-style')){let s=document.createElement('style');s.id='trust-candidate-style';s.textContent='[data-trust-candidate]::before{content:"候选任务 " attr(data-trust-candidate);color:#b50;font-weight:bold}';document.head.appendChild(s)}}''',str(i+1))
        # Labels are task ordinal only; sensitive row content remains inside the bank page.
        index=self.d.control.ask('choice',message,[f'候选任务 {i+1}' for i in range(len(rows))],pump=self.d.pump)
        if not isinstance(index,int) or index<0 or index>=len(rows): raise FlowError(Status.MANUAL,'未确认任务归属')
        return rows[index]
