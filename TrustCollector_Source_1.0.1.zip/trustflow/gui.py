import copy
import json
import os
import queue
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import date
from pathlib import Path
from .accounts import load_accounts, save_accounts
from .models import BANKS, Account, Query, Status
from .paths import user_root, resource
from .rules import FIELDS, REPEATED, TASK_CHILDREN, load_profile, save_profile, mock_profile
from .files import atomic_json
from .worker import Worker


def open_folder(path):
    path=str(Path(path).resolve())
    if os.name=='nt': os.startfile(path)
    elif sys.platform=='darwin': subprocess.Popen(['open',path])
    else: subprocess.Popen(['xdg-open',path])


class App:
    def __init__(self,root,data_root=None):
        self.root=root;self.data=Path(data_root or user_root());self.data.mkdir(parents=True,exist_ok=True)
        self.settings_path=self.data/'settings.json'
        try:self.settings=json.loads(self.settings_path.read_text(encoding='utf-8'))
        except (FileNotFoundError,ValueError):self.settings={}
        self.events=queue.Queue();self.worker=Worker(self.data,self.events);self.accounts=[];self.busy=False;self.wizard=None;self.prompt=None
        self.profiles={k:load_profile(self.data/'profiles'/f'{k}.json',k) for k in BANKS}
        root.title('三银行信托账户资金明细归集');root.geometry('1150x790');root.minsize(960,650)
        self.bank=tk.StringVar(value='三银行依次查询');self.demo=tk.BooleanVar(value=False)
        q=Query.default();self.start=tk.StringVar(value=q.start.isoformat());self.end=tk.StringVar(value=q.end.isoformat())
        self.report=tk.StringVar(value=self.settings.get('report','对账单导出'));self.output=tk.StringVar(value=self.settings.get('output',str(Path.home()/'银行流水归集')))
        self.force=tk.BooleanVar();self.status=tk.StringVar(value='就绪');self.current=tk.StringVar(value='尚未开始');self.summary=tk.StringVar(value='有明细 0　无明细 0　下载成功 0　异常 0')
        self.results=[];self.build();self.root.protocol('WM_DELETE_WINDOW',self.close);self.root.after(100,self.poll)
        p=self.settings.get('accounts','')
        if p and Path(p).exists():
            try:self.accounts=load_accounts(p);self.refresh_accounts()
            except Exception:self.status.set('上次账户表未能加载，请重新导入')
    def profile(self,bank): return mock_profile(bank) if self.demo.get() else self.profiles[bank]
    def selected_bank(self):
        return next((k for k,v in BANKS.items() if v==self.bank.get()),'ICBC')
    def button(self,frame,text,cmd):
        b=ttk.Button(frame,text=text,command=cmd);b.pack(side='left',padx=3,pady=3);return b
    def build(self):
        top=ttk.Frame(self.root,padding=10);top.pack(fill='x')
        ttk.Label(top,text='银行').pack(side='left');ttk.Combobox(top,textvariable=self.bank,values=['三银行依次查询',*BANKS.values()],state='readonly',width=19).pack(side='left',padx=6)
        self.button(top,'打开银行登录页面',self.open_bank);self.button(top,'确认登录完成',lambda:self.worker.submit('confirm',bank=self.selected_bank()))
        self.button(top,'首次页面适配向导',self.open_wizard);self.button(top,'银行设置 / 检测',self.bank_settings)
        opts=ttk.Frame(self.root,padding=(10,0));opts.pack(fill='x')
        for label,var in [('开始日期',self.start),('结束日期',self.end)]:
            ttk.Label(opts,text=label).pack(side='left');ttk.Entry(opts,textvariable=var,width=13).pack(side='left',padx=5)
        self.button(opts,'昨日至今日',self.default_dates)
        ttk.Label(opts,text='宁波报表').pack(side='left',padx=5)
        ttk.Combobox(opts,textvariable=self.report,values=['对账单导出','英文对账单导出','凭证导出','英文凭证导出','到账通知书导出'],state='readonly',width=19).pack(side='left')
        self.paths=ttk.Frame(self.root,padding=10);self.paths.pack(fill='x')
        ttk.Label(self.paths,text='输出目录').pack(side='left');ttk.Entry(self.paths,textvariable=self.output).pack(side='left',fill='x',expand=True,padx=6)
        self.button(self.paths,'选择',self.choose_output);self.button(self.paths,'打开输出文件夹',lambda:open_folder(self.output.get()))
        nb=ttk.Notebook(self.root);nb.pack(fill='both',expand=True,padx=10)
        af=ttk.Frame(nb);rf=ttk.Frame(nb);nb.add(af,text='账户配置');nb.add(rf,text='运行结果');self.notebook=nb
        bar=ttk.Frame(af);bar.pack(fill='x');self.button(bar,'导入Excel',self.import_accounts);self.button(bar,'保存Excel',self.save_accounts)
        self.button(bar,'新增账户',lambda:self.edit_account());self.button(bar,'编辑所选',self.edit_selected);self.button(bar,'删除所选',self.delete_selected)
        self.button(bar,'生成空白模板',self.template);self.button(bar,'加载虚构演示账户',self.load_demo)
        ttk.Checkbutton(bar,text='模拟银行模式',variable=self.demo).pack(side='left',padx=8)
        self.atree=ttk.Treeview(af,columns=('bank','project','number','currency','enabled','ready'),show='headings',selectmode='browse')
        for col,title,width in [('bank','银行',110),('project','信托项目名称',400),('number','账户标识',140),('currency','币种',100),('enabled','启用',70),('ready','账户配置',130)]:
            self.atree.heading(col,text=title);self.atree.column(col,width=width)
        self.atree.pack(fill='both',expand=True);self.atree.bind('<Double-1>',lambda e:self.edit_selected())
        self.rtree=ttk.Treeview(rf,columns=('bank','project','status','note'),show='headings')
        for col,title,width in [('bank','银行',100),('project','信托项目',300),('status','结果',240),('note','说明',400)]:self.rtree.heading(col,text=title);self.rtree.column(col,width=width)
        self.rtree.pack(fill='both',expand=True)
        actions=ttk.Frame(self.root,padding=10);actions.pack(fill='x')
        self.run_button=self.button(actions,'开始查询',self.run);self.retry_button=self.button(actions,'仅重试失败账户',lambda:self.run(True));self.button(actions,'重试所选账户',self.retry_selected)
        self.button(actions,'暂停',lambda:self.worker.control.paused.set());self.button(actions,'继续',lambda:self.worker.control.paused.clear())
        self.button(actions,'跳过当前账户',lambda:self.worker.control.skip.set());self.button(actions,'停止',lambda:self.worker.control.cancelled.set())
        ttk.Checkbutton(actions,text='重新查询（不复用完成结果）',variable=self.force).pack(side='left',padx=8)
        ttk.Label(self.root,textvariable=self.current,padding=(12,2)).pack(anchor='w');self.progress=ttk.Progressbar(self.root,mode='determinate');self.progress.pack(fill='x',padx=12)
        ttk.Label(self.root,textvariable=self.summary,padding=(12,4)).pack(anchor='w');ttk.Label(self.root,textvariable=self.status,padding=(12,6),wraplength=1100).pack(anchor='w')
    def idle_required(self):
        if self.busy: messagebox.showinfo('任务运行中','请完成当前任务或停止后再修改配置。');return False
        return True
    def default_dates(self):
        q=Query.default();self.start.set(q.start.isoformat());self.end.set(q.end.isoformat())
    def choose_output(self):
        p=filedialog.askdirectory()
        if p:self.output.set(p)
    def persist(self):
        self.settings.update(output=self.output.get(),report=self.report.get());atomic_json(self.settings_path,self.settings)
    def refresh_accounts(self):
        self.atree.delete(*self.atree.get_children())
        for i,a in enumerate(self.accounts):self.atree.insert('', 'end',iid=str(i),values=(BANKS[a.bank],a.project,a.masked,a.currency,'是' if a.enabled else '否','可查询' if a.ready else '待补账号/唯一选项'))
        self.status.set(f'已加载{len(self.accounts)}个账户/项目')
    def import_accounts(self):
        if not self.idle_required():return
        p=filedialog.askopenfilename(filetypes=[('Excel工作簿','*.xlsx')])
        if not p:return
        try:self.accounts=load_accounts(p);self.settings['accounts']=p;self.persist();self.refresh_accounts()
        except Exception as e:messagebox.showerror('导入失败',str(e))
    def save_accounts(self):
        p=filedialog.asksaveasfilename(defaultextension='.xlsx',initialfile='账户配置.xlsx')
        if p:
            save_accounts(p,self.accounts);self.settings['accounts']=p;self.persist();self.status.set('账户配置已保存到本机')
    def template(self):
        p=filedialog.asksaveasfilename(defaultextension='.xlsx',initialfile='账户配置模板.xlsx')
        if p:save_accounts(p,[])
    def load_demo(self):
        if not self.idle_required():return
        self.accounts=[Account(b,'虚构'+BANKS[b]+('甲' if i==1 else '乙'),'990000000000000'+str(i)) for b in BANKS for i in (1,2)]
        self.demo.set(True);self.refresh_accounts()
    def edit_selected(self):
        s=self.atree.selection()
        if s:self.edit_account(int(s[0]))
    def delete_selected(self):
        if not self.idle_required():return
        s=self.atree.selection()
        if s:self.accounts.pop(int(s[0]));self.refresh_accounts()
    def edit_account(self,index=None):
        if not self.idle_required():return
        a=copy.deepcopy(self.accounts[index]) if index is not None else Account('ICBC','')
        win=tk.Toplevel(self.root);win.title('本地账户编辑');win.geometry('700x340');vs={}
        for i,(key,title,value) in enumerate([('bank','银行',BANKS[a.bank]),('project','信托项目名称',a.project),('number','完整银行账号（文本）',a.number),('option','下拉选项精确显示文字',a.option),('currency','币种',a.currency),('enabled','是否启用','是' if a.enabled else '否')]):
            ttk.Label(win,text=title).grid(row=i,column=0,padx=10,pady=8,sticky='w');v=tk.StringVar(value=value);vs[key]=v
            if key in ('bank','enabled'):ttk.Combobox(win,textvariable=v,values=list(BANKS.values()) if key=='bank' else ['是','否'],state='readonly').grid(row=i,column=1,sticky='ew')
            else:ttk.Entry(win,textvariable=v,width=55).grid(row=i,column=1,sticky='ew')
        def save():
            bank=next(k for k,v in BANKS.items() if v==vs['bank'].get())
            item=Account(bank,vs['project'].get().strip(),vs['number'].get().strip(),vs['option'].get().strip(),vs['currency'].get().strip(),'是'==vs['enabled'].get())
            if not item.project:messagebox.showerror('未完成','请填写项目名称');return
            if index is None:self.accounts.append(item)
            else:self.accounts[index]=item
            self.refresh_accounts();win.destroy();self.status.set('已修改内存配置，请点击保存Excel持久保存')
        ttk.Button(win,text='保存修改',command=save).grid(row=6,column=1,pady=12)
    def open_bank(self):
        if not self.idle_required():return
        b=self.selected_bank();self.worker.submit('open',bank=b,profile=self.profile(b))
    def open_wizard(self):
        if not self.idle_required():return
        self.wizard=WizardWindow(self,self.selected_bank())
    def bank_settings(self):
        if not self.idle_required():return
        b=self.selected_bank();p=self.profiles[b];w=tk.Toplevel(self.root);w.title(BANKS[b]+'本地设置');w.geometry('850x630');variables={}
        entries=[('login_url','网银HTTPS登录入口',p.get('login_url','')),('mode','驱动模式（dom / uia）',p.get('mode','dom')),('date_format','页面日期格式',p.get('date_format','%Y-%m-%d')),('timeout','查询/任务等待秒数',str(p.get('timeout',30))),('download_timeout','下载等待秒数',str(p.get('download_timeout',60))),('fixed_currency','无币种控件时固定币种',p.get('fixed_currency','')),('fixed_direction','无方向控件时固定方向',p.get('fixed_direction','')),('ready_text','完成标记应含文字（可空）',p.get('ready_text','')),('empty_text','无数据标记应含文字（可空）',p.get('empty_text','')),('task_created_format','任务时间格式（ISO自动识别）',p.get('task_created_format','%Y-%m-%d %H:%M:%S')),('done_states','任务完成状态（逗号分隔）',','.join(p.get('done_states',['已完成'])))]
        for i,(key,label,value) in enumerate(entries):
            ttk.Label(w,text=label).grid(row=i,column=0,padx=10,pady=5,sticky='w');v=tk.StringVar(value=value);variables[key]=v
            if key=='mode':ttk.Combobox(w,textvariable=v,values=['dom','uia'],state='readonly').grid(row=i,column=1,sticky='ew')
            elif key=='date_format':ttk.Combobox(w,textvariable=v,values=['%Y-%m-%d','%Y/%m/%d','%Y%m%d','%Y年%m月%d日']).grid(row=i,column=1,sticky='ew')
            elif key=='task_created_format':ttk.Combobox(w,textvariable=v,values=['%Y-%m-%d %H:%M:%S','%Y/%m/%d %H:%M:%S','%Y%m%d%H%M%S','%Y-%m-%d %H:%M']).grid(row=i,column=1,sticky='ew')
            else:ttk.Entry(w,textvariable=v,width=64).grid(row=i,column=1,sticky='ew')
        amount=tk.BooleanVar(value=p.get('fixed_amount_unlimited',False));scope=tk.BooleanVar(value=p.get('export_scope_confirmed',False));blocked=tk.BooleanVar(value=p.get('state')=='安全限制不可自动化')
        ttk.Checkbutton(w,text='页面无金额控件，已确认固定金额不限',variable=amount).grid(row=11,column=1,sticky='w')
        ttk.Checkbutton(w,text='已人工核对宁波所选导出报表覆盖当前账户与日期',variable=scope).grid(row=12,column=1,sticky='w')
        ttk.Checkbutton(w,text='银行/公司安全限制不可自动化（停止此银行）',variable=blocked).grid(row=13,column=1,sticky='w')
        def save():
            try:
                for k,v in variables.items():
                    p[k]=max(1,float(v.get())) if k in ('timeout','download_timeout') else [x.strip() for x in v.get().replace('，',',').split(',') if x.strip()] if k=='done_states' else v.get().strip()
                p['fixed_amount_unlimited']=amount.get();p['export_scope_confirmed']=scope.get()
                if blocked.get():p['state']='安全限制不可自动化'
                elif p['state']=='安全限制不可自动化':p['state']='尚未配置'
                save_profile(self.data/'profiles'/f'{b}.json',p);w.destroy();self.status.set('银行设置已保存')
            except ValueError:messagebox.showerror('设置无效','超时必须为正数')
        ttk.Button(w,text='保存',command=save).grid(row=14,column=1,pady=10,sticky='w')
        ttk.Button(w,text='检测并选择现有Edge窗口（UIA）',command=lambda:self.worker.submit('windows')).grid(row=14,column=1,sticky='e')
    def run(self,retry=False,only=None):
        if not self.idle_required():return
        try:q=Query(date.fromisoformat(self.start.get()),date.fromisoformat(self.end.get()),self.report.get())
        except ValueError:messagebox.showerror('日期错误','请填写YYYY-MM-DD日期，开始日期不得晚于结束日期');return
        accounts=only or [a for a in self.accounts if a.enabled and (self.bank.get()=='三银行依次查询' or a.bank==self.selected_bank())]
        if not accounts:messagebox.showinfo('没有账户','请先导入或新增账户');return
        if any(not a.ready for a in accounts):messagebox.showerror('账户配置未完成','请在公司电脑补全完整账号或可靠唯一的下拉选项文字');return
        identities=[(a.bank,a.identity) for a in accounts]
        if len(identities)!=len(set(identities)):messagebox.showerror('重复账户','当前配置存在重复账户，请修正');return
        if self.demo.get() and any(not a.number.startswith('990000000000000') for a in accounts):messagebox.showerror('模式不一致','模拟模式只能使用虚构演示账户');return
        self.results=[];self.rtree.delete(*self.rtree.get_children());self.notebook.select(1);self.persist()
        accounts=sorted(accounts,key=lambda a:list(BANKS).index(a.bank))
        self.busy=True;self.worker.submit('run',accounts=accounts,query=q,profiles={b:self.profile(b) for b in BANKS},output=self.output.get(),retry_only=retry,force=self.force.get())
    def retry_selected(self):
        selection=self.rtree.selection()
        if not selection:return
        r=self.results[int(selection[0])]; candidates=[a for a in self.accounts if a.bank==r.bank and a.project==r.project and a.masked==r.account]
        if len(candidates)!=1:messagebox.showerror('无法唯一匹配','请在账户配置中选择该账户后再运行');return
        self.run(only=candidates)
    def choose(self,title,labels,callback):
        w=tk.Toplevel(self.root);w.title(title);w.geometry('800x430');box=tk.Listbox(w);box.pack(fill='both',expand=True,padx=8,pady=8)
        for label in labels:box.insert('end',label)
        def selected():
            s=box.curselection()
            if s:callback(s[0]);w.destroy()
        ttk.Button(w,text='选择',command=selected).pack(pady=6)
    def show_prompt(self,data):
        if self.prompt and self.prompt.winfo_exists():self.prompt.destroy()
        w=tk.Toplevel(self.root);self.prompt=w;w.title('需要人工操作');w.geometry('700x310')
        ttk.Label(w,text=data['message'],wraplength=660,padding=20).pack(fill='x')
        if data['kind']=='choice':
            var=tk.IntVar(value=-1)
            for i,label in enumerate(data['options']):ttk.Radiobutton(w,text=label,variable=var,value=i).pack(anchor='w',padx=22)
            def answer():
                if var.get()<0:return
                self.worker.control.respond(var.get());w.destroy()
        elif data['kind']=='file':
            def answer():
                p=filedialog.askopenfilename(title='选择本次下载的原始文件',filetypes=[('银行明细','*.xlsx *.xls *.csv')])
                if p:self.worker.control.respond(p);w.destroy()
        else:
            def answer():self.worker.control.respond(True);w.destroy()
        ttk.Button(w,text='已完成，继续' if data['kind']!='file' else '选择已保存文件',command=answer).pack(pady=8)
        def stop():self.worker.control.respond(None);w.destroy()
        ttk.Button(w,text='不确认，停止当前账户',command=stop).pack();w.protocol('WM_DELETE_WINDOW',stop)
    def poll(self):
        try:
            while True:
                kind,data=self.events.get_nowait()
                if kind=='busy':self.busy=True;self.status.set('正在执行：'+data)
                elif kind=='idle':self.busy=False
                elif kind=='error':self.status.set(data);messagebox.showerror('操作未完成',data)
                elif kind=='opened':self.status.set(BANKS[data]+'已打开/连接，请人工登录后确认')
                elif kind=='confirmed':self.status.set(BANKS[data]+'登录已确认')
                elif kind=='account':self.current.set(f"{BANKS[data['bank']]} / {data['project']} / {data['masked']}");self.progress.configure(maximum=data['total'],value=data['index']-1)
                elif kind=='step':self.status.set('当前步骤：'+data)
                elif kind=='prompt':self.show_prompt(data)
                elif kind=='result':
                    i=len(self.results);self.results.append(data);self.rtree.insert('','end',iid=str(i),values=(BANKS[data.bank],data.project,data.status,data.message));self.progress.step(1)
                    downloaded=sum(r.status==Status.DOWNLOADED for r in self.results);has_data=sum(r.has_data for r in self.results);empty=sum(r.status==Status.EMPTY for r in self.results);errors=len(self.results)-downloaded-empty
                    self.summary.set(f'有明细 {has_data}　无明细 {empty}　下载成功 {downloaded}　异常/跳过 {errors}')
                elif kind=='done':self.status.set('本批次处理结束。ZIP：'+(data['zip'] or '无下载文件')+'；核对日志已保存')
                elif kind=='windows':
                    if not data:messagebox.showinfo('未找到窗口','未检测到可用现有Edge窗口，请先打开Edge；无法访问时使用人工步骤。')
                    else:self.choose('选择公司授权的现有Edge窗口',[x[1] for x in data],lambda i,rows=data:self.worker.submit('attach',bank=self.selected_bank(),handle=rows[i][0]))
                elif kind=='tabs':self.choose('选择当前资金明细页面',[str(i+1)+' '+t for i,t in data],lambda i:self.worker.submit('choose_tab',bank=self.selected_bank(),index=data[i][0]))
                elif kind in ('captured','tested','uia_controls','query_responses') and self.wizard:self.wizard.event(kind,data)
        except queue.Empty:pass
        self.root.after(100,self.poll)
    def close(self):
        self.persist();self.worker.control.cancelled.set();self.worker.control.respond(None);self.worker.submit('close');self.root.destroy()


class WizardWindow:
    def __init__(self,app,bank):
        self.app=app;self.bank=bank;self.profile=copy.deepcopy(app.profile(bank));self.tests={};self.win=tk.Toplevel(app.root)
        self.win.title(BANKS[bank]+'页面适配向导');self.win.geometry('1000x760')
        ttk.Label(self.win,text='先进入资金明细页；点击“捕获”后在浏览器点击目标控件。录制时点击只用于选择，不执行业务动作。\n账户选项、结果行、任务行需先人工展开/显示；任务字段先录制任务行，再点行内对应字段。',padding=10).pack(fill='x')
        settings=ttk.Frame(self.win);settings.pack(fill='x',padx=10)
        self.scope=tk.StringVar(value='当前查询页');ttk.Label(settings,text='控件所在页面').pack(side='left')
        ttk.Combobox(settings,textvariable=self.scope,values=['当前查询页','弹出任务页'],state='readonly',width=14).pack(side='left',padx=5)
        self.modes={'完成标记变化':'marker','查询响应完成＋表格刷新':'table_response','每次人工确认':'manual'}
        self.completion=tk.StringVar(value=next((k for k,v in self.modes.items() if v==self.profile.get('query_completion','marker')),'完成标记变化'))
        ttk.Combobox(settings,textvariable=self.completion,values=list(self.modes),state='readonly',width=27).pack(side='left',padx=5)
        ttk.Button(settings,text='捕获查询响应',command=self.response_capture).pack(side='left')
        self.tree=ttk.Treeview(self.win,columns=('name','state','rule'),show='headings')
        for c,t,w in [('name','控件/步骤',220),('state','适配状态',160),('rule','本地定位属性',550)]:self.tree.heading(c,text=t);self.tree.column(c,width=w)
        self.tree.pack(fill='both',expand=True,padx=10)
        bar=ttk.Frame(self.win);bar.pack(fill='x',padx=10,pady=8)
        for text,cmd in [('捕获 / 重新录制',self.capture),('测试并高亮',self.test),('设为人工步骤',self.manual),('清除',self.clear),('选择浏览器标签',lambda:app.worker.submit('tabs',bank=bank)),('保存配置',self.save)]:app.button(bar,text,cmd)
        self.info=tk.StringVar(value='尚未开始。禁止捕获登录密码、验证码或U盾控件。');ttk.Label(self.win,textvariable=self.info,wraplength=950,padding=10).pack(fill='x')
        self.refresh()
    def refresh(self):
        selected=self.tree.selection();self.tree.delete(*self.tree.get_children())
        for key,title in FIELDS.items():
            spec=self.profile['controls'].get(key)
            state='尚未配置' if not spec else '需要人工操作' if spec.get('manual') else self.tests.get(key,'已保存，待本次测试')
            self.tree.insert('','end',iid=key,values=(title,state,json.dumps(spec or {},ensure_ascii=False)))
        if selected:self.tree.selection_set(selected)
    def field(self):
        s=self.tree.selection();return s[0] if s else None
    def capture(self):
        f=self.field()
        if not f or self.app.busy:return
        if self.profile.get('mode')=='uia':
            self.pending_field=f;self.app.worker.submit('uia_controls',bank=self.bank,profile=self.profile)
        else:
            self.app.worker.submit('capture',bank=self.bank,field=f,profile=self.profile,window='popup' if self.scope.get()=='弹出任务页' else 'main');self.info.set('请在银行网页点击目标元素；重复控件只需点击一项。停止按钮可取消捕获。')
    def response_capture(self):
        if self.app.busy:return
        if self.profile.get('mode')=='uia':self.info.set('UIA无法获取网页响应，查询完成保留人工确认。');return
        self.app.worker.submit('response_capture',bank=self.bank,profile=self.profile,window='popup' if self.scope.get()=='弹出任务页' else 'main')
    def test(self):
        f=self.field()
        if f and not self.app.busy:self.app.worker.submit('test',bank=self.bank,field=f,profile=self.profile)
    def manual(self):
        f=self.field()
        if f:
            self.profile['controls'].setdefault(f,{})['manual']=True;self.refresh()
    def clear(self):
        f=self.field()
        if f:self.profile['controls'].pop(f,None);self.tests.pop(f,None);self.refresh()
    def event(self,kind,data):
        if not self.win.winfo_exists():return
        if kind=='captured':
            if data['bank']!=self.bank:return
            self.profile['controls'][data['field']]=data['spec'];self.tests.pop(data['field'],None);self.info.set('已捕获，请测试定位并核对高亮范围。');self.refresh()
        elif kind=='tested':
            f=data['field'];n=data['count'];ok=n>0 if f in REPEATED else n==1
            self.tests[f]='需要人工操作' if n==-1 else '已成功适配' if ok else '定位失败'
            self.info.set(f'匹配数量：{n}。唯一控件应为1；重复控件需覆盖所有同类条目。');self.refresh()
        elif kind=='uia_controls':
            self.app.choose('选择UIA控件（只保存在本地）',data,lambda i:self.app.worker.submit('uia_capture',bank=self.bank,field=self.pending_field,index=i,profile=self.profile))
        elif kind=='query_responses':
            if not data:self.info.set('没有捕获到已完成XHR/fetch查询请求，请重新捕获或使用人工判定。');return
            def choose(i):
                self.profile['query_response']=data[i];self.completion.set('查询响应完成＋表格刷新');self.info.set('已保存响应候选；请使用一个账户实测，避免选择轮询或统计接口。')
            self.app.choose('选择本次资金查询响应（不含参数及正文）',[x['method']+' '+x['origin']+x['path'] for x in data],choose)
    def save(self):
        self.profile['query_completion']=self.modes[self.completion.get()]
        required=['account','account_verify','start','end','query','result','rows','ready','empty','export']
        if self.profile['query_completion']=='table_response':
            required.remove('ready')
            if not self.profile.get('query_response'):
                self.info.set('表格刷新模式需先捕获查询响应；或选择每次人工确认。');return
        if self.bank=='CITIC' or (self.bank=='ICBC' and self.profile['controls'].get('task_rows')):
            required+=['task_panel','task_open','task_close','task_ready','task_rows','task_id','task_account','task_start','task_end','task_status','task_download']
        if self.bank=='NINGBO':required+=['expanded','expand','export_menu']
        states=[self.tests.get(f,'') for f in required]
        if self.profile['query_completion']=='manual' or any(self.profile['controls'].get(f,{}).get('manual') for f in required):state='需要人工操作'
        elif all(s=='已成功适配' for s in states):state='已成功适配'
        elif any(s=='定位失败' for s in states):state='定位失败'
        else:state='尚未配置'
        self.profile['state']=state
        if self.app.demo.get():self.info.set('模拟规则为程序内置虚构规则，真实银行配置不会被覆盖。');return
        self.app.profiles[self.bank]=copy.deepcopy(self.profile);save_profile(self.app.data/'profiles'/f'{self.bank}.json',self.profile)
        self.info.set('已保存到本机。整体状态：'+state)


def main():
    root=tk.Tk();App(root);root.mainloop()
