"""Deployment blockers: real browser behavior, synthetic data only."""
import pytest
from trustflow.models import Account, Query, FlowError, Status
from trustflow.rules import mock_profile
from trustflow.page import DOMDriver
from trustflow.control import Control
from trustflow.adapters import make_adapter


@pytest.fixture
def bank(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);page=ctx.new_page();page.goto(server.url+'/icbc')
    cfg=mock_profile('ICBC');cfg.update(timeout=.8,query_completion='table_response',query_response={'path':'/query-completion-test','method':'GET'},result_settle=.08)
    page.route('**/query-completion-test*',lambda route:route.fulfill(status=200,content_type='application/json',body='{}'))
    page.evaluate("document.querySelector('#ready').hidden=false;document.querySelector('#result tbody').innerHTML='<tr><td>旧交易</td><td>1</td></tr>'")
    d=DOMDriver(page,cfg,Control())
    yield make_adapter('ICBC',d,tmp_path),d,page
    ctx.close()


def test_table_only_refresh_without_marker_mutation(bank):
    ad,d,p=bank
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test');document.querySelector('#result tbody').innerHTML='<tr><td>本次交易</td><td>200</td></tr>'}}")
    assert ad.run(Account('ICBC','虚构','9900000000000001'),Query.default()).is_file()


def test_table_only_empty_after_response(bank):
    ad,d,p=bank
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test');document.querySelector('#result tbody').innerHTML='';document.querySelector('#empty').hidden=false}}")
    assert ad.run(Account('ICBC','虚构','9900000000000001'),Query.default()) is None


@pytest.mark.parametrize('script',[
    "document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test')}",
    "document.querySelector('#query').onclick=()=>{document.querySelector('#result tbody').innerHTML='<tr><td>未确认结果</td></tr>'}",
])
def test_response_or_table_change_alone_cannot_reuse_history(bank,script):
    ad,d,p=bank;p.evaluate("()=>{"+script+";}")
    with pytest.raises(FlowError) as e:ad.run(Account('ICBC','虚构','9900000000000001'),Query.default())
    assert e.value.status==Status.TIMEOUT


def test_citic_refresh_wrong_scope_is_blocked(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic?scenario=pending')
    p.evaluate("let b=document.createElement('button');b.id='main-refresh';b.textContent='刷新';b.onclick=()=>window.wrongRefresh=true;document.body.append(b)")
    cfg=mock_profile('CITIC');cfg.update(timeout=1.2);cfg['controls']['task_panel']={'css':'#task_panel'};cfg['controls']['task_refresh']={'css':'#main-refresh'}
    d=DOMDriver(p,cfg,Control())
    try:
        with pytest.raises(FlowError) as e:make_adapter('CITIC',d,tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default())
        assert e.value.status==Status.MANUAL
        assert p.evaluate('!!window.wrongRefresh') is False
    finally:ctx.close()


def test_stale_export_receipt_cannot_authenticate_hidden_history(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic?scenario=missing_task')
    p.evaluate('''()=>{let receipt=document.createElement('span');receipt.id='receipt';receipt.textContent='history-same';document.body.append(receipt);window.oldRow=document.querySelectorAll('#tasks tbody tr')[1];oldRow.remove();document.querySelector('#export').addEventListener('click',()=>document.querySelector('#tasks tbody').append(oldRow))}''')
    cfg=mock_profile('CITIC');cfg.update(timeout=.8);cfg['controls'].pop('task_created');cfg['controls']['export_task_id']={'css':'#receipt'}
    control=Control();control.emit=lambda kind,data:control.respond(None) if kind=='prompt' else None
    try:
        with pytest.raises(FlowError):make_adapter('CITIC',DOMDriver(p,cfg,control),tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default())
        assert p.evaluate('window.downloadedTask') is None
    finally:ctx.close()


def test_task_metadata_rechecked_after_refresh(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic?scenario=pending')
    p.evaluate('''()=>{let b=document.createElement('button');b.id='task_refresh';b.textContent='刷新';b.onclick=()=>{let row=[...document.querySelectorAll('#tasks tr')].find(r=>r.querySelector('.task_id').textContent==='current-1');row.querySelector('.task_status').textContent='已完成';row.querySelector('.task_account').textContent='9900000000000003'};document.querySelector('#task_panel').append(b)}''')
    cfg=mock_profile('CITIC');cfg.update(timeout=1.5);cfg['controls']['task_refresh']={'css':'#task_refresh'}
    try:
        with pytest.raises(FlowError):make_adapter('CITIC',DOMDriver(p,cfg,Control()),tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default())
        assert p.evaluate('window.downloadedTask') is None
    finally:ctx.close()


def test_old_inflight_response_is_not_current_evidence(bank):
    ad,d,p=bank;pending=[]
    p.unroute('**/query-completion-test*');p.route('**/query-completion-test*',lambda r:pending.append(r))
    p.evaluate("()=>{fetch('/query-completion-test');}");p.wait_for_timeout(50)
    assert pending
    p.on('console',lambda msg:pending[0].fulfill(status=200,content_type='application/json',body='{}'))
    p.evaluate("()=>{document.querySelector('#query').onclick=()=>{console.log('release old synthetic request');document.querySelector('#result tbody').innerHTML='<tr><td>不可靠旧结果</td></tr>'}}")
    with pytest.raises(FlowError) as e:ad.run(Account('ICBC','虚构','9900000000000001'),Query.default())
    assert e.value.status==Status.TIMEOUT


def test_query_http_failure_never_uses_existing_table(bank):
    ad,d,p=bank
    p.unroute('**/query-completion-test*');p.route('**/query-completion-test*',lambda r:r.fulfill(status=500,body='failed'))
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test')}}")
    with pytest.raises(FlowError) as e:ad.run(Account('ICBC','虚构','9900000000000001'),Query.default())
    assert e.value.status==Status.QUERY
    assert p.evaluate('Object.keys(window.__trustWatches||{}).length')==0


def test_citic_empty_history_and_auto_open_dialog(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic');p.evaluate("document.querySelector('#tasks tbody').innerHTML=''")
    try:assert make_adapter('CITIC',DOMDriver(p,mock_profile('CITIC'),Control()),tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default()).exists()
    finally:ctx.close()


def test_response_capture_saves_endpoint_only(browser,server):
    from trustflow.worker import Worker
    from types import SimpleNamespace
    ctx=browser.new_context();p=ctx.new_page();p.goto(server.url+'/icbc')
    p.route('**/query-completion-test*',lambda r:r.fulfill(status=200,body='{}'))
    w=object.__new__(Worker);w.manager=SimpleNamespace(current=lambda bank:p);w.control=Control();events=[];w.emit=lambda kind,data:events.append((kind,data))
    def respond(kind,data):
        if kind=='prompt':
            p.evaluate("async()=>{await fetch('/query-completion-test?account=SYNTHETIC&token=NEVER_SAVE')}");p.wait_for_timeout(50);w.control.respond(True)
    w.control.emit=respond
    try:
        w.do_response_capture('ICBC',mock_profile('ICBC'));rows=events[-1][1]
        assert rows and rows[0]['path']=='/query-completion-test'
        assert 'NEVER_SAVE' not in str(rows) and 'SYNTHETIC' not in str(rows)
    finally:ctx.close()


def test_task_refresh_can_temporarily_replace_entire_grid(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic?scenario=pending')
    p.evaluate('''()=>{let b=document.createElement('button');b.id='task_refresh';b.textContent='刷新';b.onclick=()=>{let body=document.querySelector('#tasks tbody');let nodes=[...body.children];body.replaceChildren();setTimeout(()=>{for(let row of nodes){row.querySelector('.task_status').textContent='已完成';body.append(row)}},80)};document.querySelector('#task_panel').append(b)}''')
    cfg=mock_profile('CITIC');cfg.update(timeout=2);cfg['controls']['task_refresh']={'css':'#task_refresh'}
    try:assert make_adapter('CITIC',DOMDriver(p,cfg,Control()),tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default()).exists()
    finally:ctx.close()


def test_preclick_background_request_cannot_authenticate_result(bank):
    ad,d,p=bank
    p.evaluate('''()=>{let b=document.querySelector('#query');b.disabled=true;b.onclick=()=>{};setTimeout(async()=>{await fetch('/query-completion-test');document.querySelector('#result tbody').innerHTML='<tr><td>点击前后台结果</td></tr>';setTimeout(()=>b.disabled=false,120)},30)}''')
    with pytest.raises(FlowError) as e:d.query()
    assert e.value.status==Status.TIMEOUT


def test_citic_receipt_created_only_after_first_export(browser,server,tmp_path):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic')
    p.evaluate('''()=>{document.querySelector('#export').addEventListener('click',()=>{let r=document.createElement('span');r.id='receipt';r.textContent='current-1';document.body.append(r)})}''')
    cfg=mock_profile('CITIC');cfg.update(timeout=2);cfg['controls'].pop('task_created');cfg['controls']['export_task_id']={'css':'#receipt'}
    try:assert make_adapter('CITIC',DOMDriver(p,cfg,Control()),tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default()).exists()
    finally:ctx.close()


def test_task_identity_normalizes_padding(browser,server):
    ctx=browser.new_context();p=ctx.new_page();p.goto(server.url+'/citic');p.locator('.task_id').first.evaluate("e=>e.textContent=' \\n history-1 \\t '")
    try:assert DOMDriver(p,mock_profile('CITIC'),Control()).bind_task('history-1').count()==1
    finally:ctx.close()


def test_popup_query_observers_and_response_capture(browser,server):
    from trustflow.worker import Worker
    from types import SimpleNamespace
    ctx=browser.new_context();main=ctx.new_page();popup=ctx.new_page();popup.goto(server.url+'/icbc')
    popup.route('**/query-completion-test*',lambda r:r.fulfill(status=200,body='{}'))
    cfg=mock_profile('ICBC');cfg.update(timeout=1,query_completion='table_response',query_response={'path':'/query-completion-test','method':'GET'},result_settle=.08)
    for spec in cfg['controls'].values():spec['window']='popup'
    popup.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test');document.querySelector('#result tbody').innerHTML='<tr><td>本次弹出页结果</td></tr>'}}")
    try:
        assert DOMDriver(main,cfg,Control()).query()=='data'
        w=object.__new__(Worker);w.manager=SimpleNamespace(current=lambda bank:main);w.control=Control();events=[];w.emit=lambda kind,data:events.append((kind,data))
        def respond(kind,data):
            if kind=='prompt':popup.locator('#query').click();popup.wait_for_timeout(50);w.control.respond(True)
        w.control.emit=respond;w.do_response_capture('ICBC',cfg,window='popup')
        assert events[-1][1][0]['path']=='/query-completion-test'
    finally:ctx.close()


@pytest.mark.parametrize('popup_delay',[0,1200])
def test_popup_task_window_can_open_from_absent_state(browser,server,tmp_path,popup_delay):
    ctx=browser.new_context(accept_downloads=True);p=ctx.new_page();p.goto(server.url+'/citic')
    # A separate popup task page reads the same synthetic backend records.
    p.evaluate('''()=>{document.querySelector('#task_open').onclick=()=>{let w=window.open('/citic');w.addEventListener('load',()=>{setTimeout(()=>{w.document.querySelector('#tasks tbody').innerHTML=document.querySelector('#tasks tbody').innerHTML;w.document.querySelector('#task_panel').showModal();w.document.querySelector('#task_close').onclick=()=>w.close();let refresh=w.document.createElement('button');refresh.id='task_refresh';refresh.textContent='刷新';w.document.querySelector('#task_panel').append(refresh);w.document.querySelectorAll('.task_download').forEach(b=>b.onclick=()=>{let a=w.document.createElement('a');a.href='/download';a.click()})},window.popupDelay)})}}''')
    p.evaluate('(v)=>window.popupDelay=v',popup_delay)
    cfg=mock_profile('CITIC');cfg.update(timeout=2);cfg['controls']['task_refresh']={'css':'#task_refresh','window':'popup'}
    for name,spec in cfg['controls'].items():
        if name.startswith('task_') and name!='task_open':spec['window']='popup'
    # Submit into main backing table; popup opens after the asynchronous task exists.
    p.evaluate("()=>{document.querySelector('#export').onclick=()=>{addTask('current-popup',document.querySelector('#account_verify').textContent,document.querySelector('#start').value,document.querySelector('#end').value,'已完成')}}")
    try:assert make_adapter('CITIC',DOMDriver(p,cfg,Control()),tmp_path).run(Account('CITIC','虚构','9900000000000001'),Query.default()).exists()
    except Exception:
        print('Synthetic popup diagnostics:',[(x.url,x.is_closed()) for x in ctx.pages]);raise
    finally:ctx.close()


def test_clearing_table_before_response_cannot_confirm_old_empty(bank):
    ad,d,p=bank
    p.locator('#empty').evaluate('e=>e.hidden=false')
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{document.querySelector('#result tbody').replaceChildren();await fetch('/query-completion-test')}}")
    with pytest.raises(FlowError) as e:d.query()
    assert e.value.status==Status.TIMEOUT


def test_marker_change_alone_cannot_authenticate_old_rows(bank):
    ad,d,p=bank;d.cfg['query_completion']='marker'
    p.evaluate("()=>{document.querySelector('#query').onclick=()=>{let e=document.querySelector('#ready');e.hidden=true;setTimeout(()=>e.hidden=false,30)}}")
    with pytest.raises(FlowError) as e:d.query()
    assert e.value.status==Status.TIMEOUT


def test_clearing_after_response_cannot_confirm_old_empty(bank):
    ad,d,p=bank;p.locator('#empty').evaluate('e=>e.hidden=false')
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test');document.querySelector('#result tbody').replaceChildren()}}")
    with pytest.raises(FlowError) as e:d.query()
    assert e.value.status==Status.TIMEOUT


def test_ready_text_change_cannot_authenticate_old_data_rows(bank):
    ad,d,p=bank
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test');document.querySelector('#ready').textContent='查询完成（新文本，旧表格）'}}")
    with pytest.raises(FlowError) as e:d.query()
    assert e.value.status==Status.TIMEOUT


def test_empty_indicator_created_dynamically_is_captured(bank):
    ad,d,p=bank;p.locator('#empty').evaluate('e=>e.remove()')
    p.evaluate("()=>{document.querySelector('#query').onclick=async()=>{await fetch('/query-completion-test');document.querySelector('#result tbody').replaceChildren();let e=document.createElement('i');e.id='empty';e.textContent='无交易记录';document.querySelector('#result').append(e)}}")
    assert d.query()=='empty'


def test_manual_query_with_automatic_result_rules_can_resume(bank):
    ad,d,p=bank;d.cfg['controls']['query']['manual']=True
    def respond(kind,data):
        if kind=='prompt':d.control.respond(0 if data['kind']=='choice' else True)
    d.control.emit=respond
    assert d.query()=='data'


def test_task_close_waits_before_reopening(browser,server,tmp_path):
    ctx=browser.new_context();p=ctx.new_page();p.goto(server.url+'/citic');p.locator('#task_open').click()
    p.evaluate("()=>{document.querySelector('#task_close').onclick=()=>setTimeout(()=>document.querySelector('#task_panel').close(),200)}")
    d=DOMDriver(p,mock_profile('CITIC'),Control());ad=make_adapter('CITIC',d,tmp_path)
    try:ad.close_tasks();assert not p.locator('#task_panel').is_visible()
    finally:ctx.close()


def test_task_popup_uses_unique_recorded_container_among_blank_tabs(browser):
    ctx=browser.new_context();main=ctx.new_page();blank=ctx.new_page();task=ctx.new_page()
    task.set_content('<section id="panel"><span id="receipt">current-1</span><button id="refresh">刷新</button></section>')
    cfg=mock_profile('CITIC');cfg['controls']['task_panel']={'css':'#panel','window':'popup'};cfg['controls']['task_refresh']={'css':'#refresh','window':'popup'}
    cfg['controls']['export_task_id']={'css':'#receipt','window':'popup'}
    d=DOMDriver(main,cfg,Control())
    try:
        d.task_action('task_refresh')
        assert d.read('export_task_id')=='current-1'
        other=ctx.new_page();other.set_content('<section id="panel"><button id="refresh">其他窗口</button></section>')
        # Once positively bound, later tabs cannot redirect the already matched task page.
        assert d.read('task_refresh')=='刷新'
        task.close()
        assert d.read('task_refresh')=='其他窗口'
    finally:ctx.close()


def test_ambiguous_task_popup_containers_require_manual(browser):
    ctx=browser.new_context();main=ctx.new_page()
    for _ in range(2):ctx.new_page().set_content('<section id="panel">任务</section>')
    cfg=mock_profile('CITIC');cfg['controls']['task_panel']={'css':'#panel','window':'popup'}
    try:
        with pytest.raises(FlowError) as e:DOMDriver(main,cfg,Control()).one('task_panel')
        assert e.value.status==Status.MANUAL
    finally:ctx.close()
