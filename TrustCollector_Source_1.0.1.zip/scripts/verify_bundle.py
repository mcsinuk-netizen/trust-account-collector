"""Executed by native Windows build; frozen EXE must run three-bank offline smoke test."""
import json
import os
import struct
import subprocess
from pathlib import Path

root=Path(__file__).resolve().parent.parent
import sys
sys.path.insert(0,str(root))
from trustflow import __version__
assert os.name=='nt','Windows EXE只能在实际Windows环境验证'
exe=root/'dist/TrustCollector/TrustCollector.exe'
with exe.open('rb') as f:
    assert f.read(2)==b'MZ'
    f.seek(0x3c);offset=struct.unpack('<I',f.read(4))[0];f.seek(offset);assert f.read(4)==b'PE\0\0';assert struct.unpack('<H',f.read(2))[0]==0x8664
report=root/'reports/windows-frozen-selftest.json'
report.unlink(missing_ok=True)
subprocess.run([str(exe),'--self-test',str(report),'--edge'],check=True,timeout=180)
data=json.loads(report.read_text(encoding='utf-8'))
assert data['success'] and data['frozen'] and data['platform']=='Windows'
assert data['banks']=={'ICBC':'pass','CITIC':'pass','NINGBO':'pass'}
assert data['tk']=='pass'
assert data['version']==__version__ and data['windows_uia_runtime']=='pass'
print('Windows x64 EXE, Tk and three-bank download smoke tests passed')
